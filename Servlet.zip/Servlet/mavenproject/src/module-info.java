module mavenproject {
	requires java.logging;
}