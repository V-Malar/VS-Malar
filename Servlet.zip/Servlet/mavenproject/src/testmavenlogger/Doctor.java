package testmavenlogger;

import java.util.logging.Logger;

public class Doctor {
	public static void main(String[] args) {
		Doctor mc=new Doctor();
		mc.doCure();
	}
	private static final String CLASS_NAME = Doctor.class.getName();
	private static Logger logger = Logger.getLogger(CLASS_NAME);
	
	public void doCure() {
		try {
		String methodName = "doCure";
		System.out.println(CLASS_NAME);
		logger.entering(CLASS_NAME, "enter the dragon");
		logger.info("Cure method Called");
		logger.exiting(CLASS_NAME, "exit the dragon");
		logger.info("This method performs do cure...");
		}catch(Exception e) {
			logger.info("got exception...");
		}
	}
}