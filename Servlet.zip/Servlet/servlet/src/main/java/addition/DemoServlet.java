package addition;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/demo")
public class DemoServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name="Shinchan";
		
		Student student = new Student(7, "Shinchan");
		request.setAttribute("rollno", student.getRollno());
		request.setAttribute("name", student.getName());
		//or
		request.setAttribute("student", student);
		//or
		List<Student> studentlist = Arrays.asList(new Student(5, "Shiro"), 
												  new Student(5, "Shinchan"),
												  new Student(5, "Neni"),
												  new Student(5, "Masaw"),
												  new Student(5, "Bo-Chan"),
												  new Student(5, "Kazama"));
		request.setAttribute("list", studentlist);
		RequestDispatcher rd = request.getRequestDispatcher("Demo.jsp");
		rd.forward(request, response);
	}
}
