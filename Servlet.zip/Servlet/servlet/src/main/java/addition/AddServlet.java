package addition;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/add")
public class AddServlet extends HttpServlet {
	// service method also works
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		//doPost(request, response);
		
		ServletConfig sconfig = getServletConfig();
		ServletContext sctx = getServletContext();
		
		PrintWriter out = response.getWriter();
		out.println("SERVLET CONFIGURATION");
		String name = sconfig.getInitParameter("name");
		String bestfriend = sctx.getInitParameter("bestfriend");
		
		out.println("Name: " + name + " BestFriend: " + bestfriend);
		
		int i = Integer.parseInt(request.getParameter("num1"));
		int j = Integer.parseInt(request.getParameter("num2"));

		int result = i + j;

//		same page		
//		PrintWriter out = response.getWriter();
//		out.println("Result: " + result);
		
		// Forward
//		request.setAttribute("result", result);
//		
//		RequestDispatcher rd = request.getRequestDispatcher("sqr");
//		rd.forward(request, response);
		
//		Comes under session management		
		// Redirect
//		response.sendRedirect("sqr?result="+result);// pass value from result (same url but from user)
		//Redirect
//		response.sendRedirect("sqr");//Get the input value from the URL line;
		
		//Session - same values accross multiple servlets passing within one application
//		HttpSession session = request.getSession();
//		session.setAttribute("result", result);
//		response.sendRedirect("sqr");
		
		// Cookies comes from client side and sent it to the server
		Cookie resultCookie = new Cookie("result", result+"");
		response.addCookie(resultCookie);
		response.sendRedirect("sqr"); // comment this for ServletContext and ServletConfig view
		
	}
	
//	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
//	{
//		int i = Integer.parseInt(request.getParameter("num1"));
//		int j = Integer.parseInt(request.getParameter("num2"));
//
//		int result = i + j;
//		
//		PrintWriter out = response.getWriter();
//		out.println("Result: " + result);
//		
//		result = result*result;
//		
//		RequestDispatcher rd = request.getRequestDispatcher("sqrt");
//		rd.forward(request, response);
//	}
}
