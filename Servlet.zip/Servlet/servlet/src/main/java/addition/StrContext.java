package addition;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/sqr")
public class StrContext extends HttpServlet{
public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException
{
	ServletContext strctx = getServletContext();
	String name = strctx.getInitParameter("name");
	String bestfriend = strctx.getInitParameter("bestfriend");
	
	PrintWriter out = response.getWriter();
	out.println("Name: " + name + " Best Friend: " + bestfriend);
}

}
