package innerclass;

import innerclass.Vastprocompany.Vastproteashop;

public class InnerClass {

	public static void main(String[] args) {
		RoadTeaShop rt = new RoadTeaShop();
		rt.service();
		Vastproteashop vt = new Vastproteashop();
		vt.service();
		
		

	}

}

interface teasshop {

	public void service();

}

class RoadTeaShop implements teasshop {

	@Override
	public void service() {

		System.out.println("This is road side tea shop is common for all the peoples");

	}

}

class Vastprocompany {

	  static class Vastproteashop implements teasshop {

		@Override
		public void service() {
			System.out.println("This tea shop is only for the vastpro peoples");

		}

		public void products() {
			
		}

	}
}

//class Innerclass2 extends Vastprocompany{
//	public static void main(String[] args) {
//		Vastproteashop vs=new Vastproteashop();
//		
//	}
//}
