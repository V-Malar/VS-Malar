package myrest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
//http://localhost:2020/myrestproj/rest/laxmi
@Path("malar")
public class VastproService {
	
	@GET
	public void sayHello() {
		System.out.println("welcome to rest....");
	}
}