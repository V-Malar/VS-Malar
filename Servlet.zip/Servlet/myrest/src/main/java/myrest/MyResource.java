package myrest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
@Path("/api")
public class MyResource {
    @Context
    private HttpServletRequest request;
    @POST
    @Path("/login")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response login(@FormParam("username") String username, @FormParam("password") String password) {
        // Simulate user authentication (replace with your actual authentication logic)
        if ("user123".equals(username) && "password123".equals(password)) {
            // Create a new session or get the existing one
            HttpSession session = request.getSession(true);
            session.setAttribute("authenticated", true);
            return Response.ok("Login successful").build();
        } else {
            return Response.status(Response.Status.UNAUTHORIZED).entity("Login failed").build();
        }
    }
    @GET
    @Path("/protected")
    @Produces(MediaType.TEXT_PLAIN)
    public Response getProtectedResource() {
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("authenticated") != null) {
            return Response.ok("Protected resource accessed").build();
        } else {
            return Response.status(Response.Status.UNAUTHORIZED).entity("Unauthorized").build();
        }
    }
}