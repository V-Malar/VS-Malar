package myrest;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/panchatanthra")
public class MyService {

	@GET // no need to give the / name automatically run when /panchatanthra
	public void sayHello() {
		System.out.println("say hello method called...");
	}

	@GET
	@Path("/hello")
	public void sayHello3() {
		System.out.println("say hello method2 called...");
	}

	@POST
	@Path("/submit")
	public void sayHello2() {
		System.out.println("say hello method called.2222222222222222222..");
	}

	@Path("/user")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	// @Produces("application/json")
	public User listUser() {
		System.out.println("list user user user method called...");
		return new User(3, "salman khan");
	}

	@Path("/users")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	// @Produces("application/json")
	public List<User> listUsers() {
		System.out.println("list user method called.....");
		return Arrays.asList(new User(1, "shoiab"), new User(2, "newcollege"));
	}

	@Path("/setusers")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	// @Consumes("application/json")
	public void setUsers(List<User> users) {
		System.out.println("write the logic to handle the object");
		Iterator<User> iter = users.iterator();
		while (iter.hasNext()) {
			System.out.println(iter.next());
		}
	}

}
