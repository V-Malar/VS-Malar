package myrest;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/react")
public class Calculator {
	@POST
	@Path("/add")
	@Produces(MediaType.TEXT_PLAIN)
	public int greet(@QueryParam("num1") int num1, @QueryParam("num2") int num2) {
		return num1 + num2;
	}
}