package control;

import java.util.Properties;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import action.Action;
import controller.Executor;
import controller.Property;
import controller.Setter;

public class RequestProcessor {
	private String CLASS_NAME = "";
	private static Logger logger;
	public String process(HttpServletRequest request, HttpServletResponse response) {

		try {
			HttpSession session = request.getSession();
			session.setMaxInactiveInterval(2000);

			String formid = request.getAttribute("formid").toString();
			Setter.setter(formid);

			Properties prop = Property.getFormProperty(request, response);
			String actionclass = prop.getProperty(formid);
			
			Action action = Executor.execute(actionclass);
			String result = action.execute(request, response);

		CLASS_NAME = actionclass;
		logger = Logger.getLogger(CLASS_NAME);
		System.out.println(logger);
		logger.entering(CLASS_NAME, "Entering");
		logger.info("Executing the execute method");
		action.init(logger);
		
//		String nextpage=prop.getProperty(result);
//		
//		System.out.println(result);
//		RequestDispatcher rd=request.getRequestDispatcher(nextpage);
//		rd.forward(request, response);
			return result;
		} catch (Exception e) {
			logger.warning(e.getMessage());
			// e.printStackTrace();
		}
		return null;
	}
}

//public String process(HttpServletRequest request,HttpServletResponse response) {
//	
//	try {
//	HttpSession session=request.getSession();
//	session.setMaxInactiveInterval(2000);
//	ServletContext ctx=request.getServletContext();
//	Properties prop=(Properties)ctx.getAttribute("prop");
//	String formid=request.getAttribute("formid").toString();
//	System.out.println(formid);
//	String actionclass=prop.getProperty(formid);
//	System.out.println(actionclass);
//	Action action=(Action)Class.forName(actionclass).getConstructor().newInstance();
////	CLASS_NAME = actionclass;
////	logger = Logger.getLogger(CLASS_NAME);
////	System.out.println(logger);
////	logger.entering(CLASS_NAME, "Entering");
////	logger.info("Executing the execute method");
//	String result=action.execute(request, response);
////	action.init(logger);
////	String nextpage=prop.getProperty(result);
////	
////	System.out.println(result);
////	RequestDispatcher rd=request.getRequestDispatcher(nextpage);
////	rd.forward(request, response);
//	return result;
//	}catch(Exception e) {
////		logger.warning(e.getMessage());
//		//e.printStackTrace();
//	}
//	return null;
//}
