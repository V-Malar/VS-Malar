package action;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.CustomerServiceImpl;

public class ShoppingAction extends Action {
	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String shopid = request.getAttribute("carts").toString();
		HttpSession session = request.getSession();
		Enumeration<String> e = request.getParameterNames();
		List<String> list = (List<String>) session.getAttribute("list");
		List<String> list2 = new ArrayList();
		int total = 0;
		while (e.hasMoreElements()) {
			String name = e.nextElement().toString();
			if (!(name.equals("formid") || name.equals("shopid"))) {
				list.add(name);
				list2.add(name);
				System.out.println(list2.toString());
			}
			String value = request.getParameter(name).toString();
//			if (name.equals(
//					"https://c4.wallpaperflare.com/wallpaper/567/218/528/apples-fruit-cut-leaf-wallpaper-preview.jpg")) {
//				total += Integer.parseInt(value) * Integer.parseInt(request.getParameter("count1"));
////				session.setAttribute(name, Integer.parseInt(value)*Integer.parseInt(request.getParameter("count1")));
////				list2.add(Integer.parseInt(value)*Integer.parseInt(request.getParameter("count1")));
//			} 
//			if (name.equals(
//					"https://media.istockphoto.com/id/636739634/photo/banana.jpg?s=612x612&w=0&k=20&c=pO0985tQi1LpWRlWqpRvbab8S5yxgnEOVcs5CHIlcDE=")) {
//				session.setAttribute(name, Integer.parseInt(value) * Integer.parseInt(request.getParameter("count2")));
//				total += Integer.parseInt(value) * Integer.parseInt(request.getParameter("count2"));
//			} 
//			if (name.equals("https://pngfre.com/wp-content/uploads/orange-6-1024x770.png")) {
//				session.setAttribute(name, Integer.parseInt(value) * Integer.parseInt(request.getParameter("count3")));
//				total += Integer.parseInt(value) * Integer.parseInt(request.getParameter("count3"));
//			} else if (name.equals("count4")) {
//				session.setAttribute(name, Integer.parseInt(value) * Integer.parseInt(request.getParameter("count4")));
//				total += Integer.parseInt(value) * Integer.parseInt(request.getParameter("count4"));
//			} else if (name.equals("count5")) {
//				session.setAttribute(name, Integer.parseInt(value) * Integer.parseInt(request.getParameter("count5")));
//				total += Integer.parseInt(value) * Integer.parseInt(request.getParameter("count5"));
//			} else if (name.equals("count6")) {
//				session.setAttribute(name, Integer.parseInt(value) * Integer.parseInt(request.getParameter("count6")));
//				total += Integer.parseInt(value) * Integer.parseInt(request.getParameter("count6"));
//			} else if (name.equals("count7")) {
//				session.setAttribute(name, Integer.parseInt(value) * Integer.parseInt(request.getParameter("count7")));
//				total += Integer.parseInt(value) * Integer.parseInt(request.getParameter("count7"));
//			} else if (name.equals("count8")) {
//				session.setAttribute(name, Integer.parseInt(value) * Integer.parseInt(request.getParameter("count8")));
//				total += Integer.parseInt(value) * Integer.parseInt(request.getParameter("count8"));
//			} else if (name.equals("count9")) {
//				session.setAttribute(name, Integer.parseInt(value) * Integer.parseInt(request.getParameter("count9")));
//				total += Integer.parseInt(value) * Integer.parseInt(request.getParameter("count9"));
//			}
			session.setAttribute(name, value);
		}
		return shopid + ".success";

	}

	
	@Override
	public void init(Logger log) {
		// TODO Auto-generated method stub
		log.info("Working in ShoppingAction class");
	}
}
