package action;


import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public abstract class Action {
	public abstract void init(Logger log);
	public abstract String execute(HttpServletRequest request,HttpServletResponse response);
}
