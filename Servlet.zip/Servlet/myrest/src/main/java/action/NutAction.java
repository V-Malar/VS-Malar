package action;

import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.InvoiceDAO;
import dao.InvoiceDAOImpl;
import dto.InvoiceDTO;
import service.CustomerServiceImpl;

public class NutAction extends Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) {
//		hs = request.getSession(); 
//		Enumeration<String> e = request.getParameterNames();
		CustomerServiceImpl cs = new CustomerServiceImpl();
		HttpSession session = request.getSession();
		String uname = (String) session.getAttribute("uname");
		System.out.println(session.getAttribute("uname"));
		String name = request.getParameter("product");
		int value = Integer.parseInt(request.getParameter("count"));
		try {
			cs.updateNuts(name, value);
			System.out.println("Inert invoice called");
			insertinvoice(cs, uname, name);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Table Fruits updated successfully";
	}

	@Override
	public void init(Logger log) {
		// TODO Auto-generated method stub
		log.info("Working in NutAction class");
	}
	public void insertinvoice(CustomerServiceImpl cs, String uname, String name)
	{
		try
		{
			int id = cs.getUserCId(uname);
			InvoiceDTO dto = new InvoiceDTO();
			InvoiceDAO in = new InvoiceDAOImpl();
			dto.setC_id(id);
			dto.setProduct(name);
			System.out.println(dto);
			in.insertInvoice(dto);
			
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
}
