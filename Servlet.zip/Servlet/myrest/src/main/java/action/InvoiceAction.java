//package action;
//
//import java.util.ArrayList;
//import java.util.Enumeration;
//import java.util.List;
//import java.util.logging.Logger;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.HttpSession;
//
//import service.CustomerService;
//import service.CustomerServiceImpl;
//
//public class InvoiceAction extends Action implements Cloneable {
//	HttpSession hs;
//
//	public InvoiceAction() {
//		System.out.println("Invoice action called...");
//	}
//
//	private static InvoiceAction is;
//
//	synchronized public static InvoiceAction getServiceImpl() {
//		if (is == null) {
//			is = new InvoiceAction();
//			return is;
//		} else {
//			return is.createClone();
//		}
//	}
//
//	private InvoiceAction createClone() {
//		try {
//			return (InvoiceAction) super.clone();
//		} catch (Exception e) {
//			e.printStackTrace();
//			return null;
//		}
//	}
//
////	@Override
////	public void init(Logger log) {
////		// TODO Auto-generated method stub
////		log.info("Updating the stock tables");
////	}
//
//	@Override
//	public String execute(HttpServletRequest request, HttpServletResponse response) {
////		hs = request.getSession(); 
////		Enumeration<String> e = request.getParameterNames();
//		System.out.println("Invoice check..");
//		CustomerServiceImpl cs = new CustomerServiceImpl();
//		String name = request.getParameter("product");
//		int value = Integer.parseInt(request.getParameter("count"));
//		try {
//			System.out.println(name + " " + value);
//			cs.updateFruits(name, value);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
////		System.out.println("Name: " + name + "Value: " + value);
//		return "login.success";
//	}
//	
//
//	@Override
//	public void init(Logger log) {
//		// TODO Auto-generated method stub
//		log.info("Working in InvoiceAction class");
//	}
//
////	@Override
////	public String execute(HttpServletRequest request, HttpServletResponse response) {
////		String uname = request.getParameter("product");
////		String upass = request.getParameter("count");
////		HttpSession hs = request.getSession();
////		Enumeration<String> e = request.getParameterNames();
////		List<String> cartlist = new ArrayList<String>();
////		while (e.hasMoreElements())
////		{
////			String name = e.nextElement().toString();
////			String value = request.getParameter(name).toString();
////			if (name.equals("cart"))
////			{
////				cartlist.add(name + "," + request.getParameter(name).toString());
////			}
////		}
////		System.out.println(cartlist);
////		return "success";
////	}
//
//}
