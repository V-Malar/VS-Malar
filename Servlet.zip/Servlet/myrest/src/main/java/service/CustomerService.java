package service;

public interface CustomerService {
	public boolean checkUser(String uname,String pwd);
	public int updateFlag(int flag,String cust_name);
	public boolean checkFlag(String uname);
	int updateFruits(String name, int value);
	int updateVegetables(String name, int value);
	int updateNuts(String name, int value);
	int getUserCId(String uname);
	String findUserEmail(String user);
}
