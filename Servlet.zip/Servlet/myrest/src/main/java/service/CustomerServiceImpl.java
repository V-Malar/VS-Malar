package service;

import dao.CustomerRegDAO;
import dao.CustomerRegDAOImpl;
import dao.ShopDAO;
import dto.CustomerRegDTO;
import dto.ShopDTO;
import shop.Shop1;
import shop.Shop2;
import shop.Shop3;

public class CustomerServiceImpl implements CustomerService, Cloneable {

	public CustomerServiceImpl() {
	}

	private static CustomerServiceImpl cs;

	synchronized public static CustomerServiceImpl getServiceImpl() {
		if (cs == null) {
			cs = new CustomerServiceImpl();
			return cs;
		} else {
			return cs.createClone();
		}
	}

	private CustomerServiceImpl createClone() {
		try {
			return (CustomerServiceImpl) super.clone();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public boolean checkFlag(String uname) {
		CustomerRegDAO cdao = CustomerRegDAOImpl.getServiceImpl();
		CustomerRegDTO dto = cdao.findByName(uname);
		if (dto != null) {
			int flagvalue = dto.getFlag();
			if (flagvalue == 0) {
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

	@Override
	public boolean checkUser(String uname, String pwd) {
		CustomerRegDAO cdao = CustomerRegDAOImpl.getServiceImpl();
		CustomerRegDTO dto = cdao.findByName(uname);
		if (dto != null) {
			if (dto.getPassword().equals(pwd)) {
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

	@Override
	public int getUserCId(String uname) {
		CustomerRegDAO cdao = CustomerRegDAOImpl.getServiceImpl();
		CustomerRegDTO dto = cdao.findByName(uname);
		if (dto != null) {
			System.out.println(dto.getC_id());
			return dto.getC_id();
		} else {
			return 0;
		}
	}

	@Override
	public int updateFruits(String name, int value) {
		ShopDAO<Shop1> sdao = Shop1.getServiceImpl();
		ShopDTO<Shop1> dto = new Shop1().findByName(name);
		if (dto != null) {
			int updatedvalue = dto.getStock() - value;
			dto.setStock(updatedvalue);
			sdao.updateShop(dto);
			return 1;
		}
		return 0;
	}

	@Override
	public int updateVegetables(String name, int value) {
		ShopDAO<Shop2> sdao = Shop2.getServiceImpl();
		ShopDTO<Shop2> dto = new Shop2().findByName(name);
		if (dto != null) {
			int updatedvalue = dto.getStock() - value;
			dto.setStock(updatedvalue);
			sdao.updateShop(dto);
			return 1;
		}
		return 0;
	}

	@Override
	public int updateNuts(String name, int value) {
		ShopDAO<Shop3> sdao = Shop3.getServiceImpl();
		ShopDTO<Shop3> dto = new Shop3().findByName(name);
		if (dto != null) {
			int updatedvalue = dto.getStock() - value;
			dto.setStock(updatedvalue);
			sdao.updateShop(dto);
			return 1;
		}
		return 0;
	}

	@Override
	public int updateFlag(int flag, String cust_name) {
		CustomerRegDAO cdao = CustomerRegDAOImpl.getServiceImpl();
		CustomerRegDTO dto = cdao.findByName(cust_name);
		if (dto != null) {
			dto.setFlag(flag);
			cdao.updateCustomer(dto);
			return 1;
		}
		return 0;
	}
	@Override
public String findUserEmail(String user)
{
		CustomerRegDAO cdao = CustomerRegDAOImpl.getServiceImpl();
		CustomerRegDTO dto = cdao.findByName(user);
		return dto.getEmail();
}
}
