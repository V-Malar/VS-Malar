package controller;

import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Property {
public static Properties getFormProperty(HttpServletRequest request, HttpServletResponse response)
{
	ServletContext ctx = request.getServletContext();
	Properties prop = (Properties) ctx.getAttribute("prop");
	return prop;
}
}
