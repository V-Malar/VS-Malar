package controller;

import java.lang.reflect.InvocationTargetException;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;

public class Executor {
	public static Action execute(String actionclass) throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, ClassNotFoundException {
		
		
		System.out.println(actionclass);
		Action action = (Action) Class.forName(actionclass).getConstructor().newInstance();
		
		return action;
	}
}
