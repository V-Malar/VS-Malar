package controller;

import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Setter {
	public static String setter(String formid) {

		System.out.println(formid);
		return formid;
	}
}
