//package dao;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.util.ArrayList;
//import java.util.List;
//
//import control.ConnectionUtility;
//import shop.Shop;
//
//public class ShopDAOImpl implements ShopDAO<Shop>{
//public static void main(String[] args) {
//	System.out.println(new ShopDAOImpl().findAll());
//}
//	@Override
//	public ShopDTO<Shop> findByName(String name) {
//		PreparedStatement ps;
//		try
//		{
//			Connection con = ConnectionUtility.getConnection();
//			ps = con.prepareStatement("select * from shopcart1 where item_name = ?");
//			ps.setString(1, name);
//			ResultSet rs = ps.executeQuery();
//			ShopDTO<Shop> dto = new ShopDTO<Shop>();
//			if (rs.next())
//			{
//				dto.setItem_name(rs.getString(2));
//				dto.setPrice(rs.getFloat(3));
//				dto.setImage(rs.getBlob(4));
//				System.out.println(dto);
//			}
//			else
//			{
//				return null;
//			}
//			ConnectionUtility.closeConnection(null, null);
//			return dto;
//		}
//		catch (Exception e) {
//			ConnectionUtility.closeConnection(e, null);
//			return null;
//		}
//	}
//
//	@Override
//	public List<ShopDTO<Shop>> findAll() {
//		PreparedStatement ps;
//		try
//		{
//			Connection con = ConnectionUtility.getConnection();
//			ps = con.prepareStatement("select * from shopcart1");
//			ResultSet rs = ps.executeQuery();
//			List<ShopDTO<Shop>> list = new ArrayList<ShopDTO<Shop>>();
//			while (rs.next())
//			{
//				ShopDTO<Shop> dto = new ShopDTO<Shop>();
//				dto.setShopid(rs.getInt(1));
//				dto.setItem_name(rs.getString(2));
//				dto.setPrice(rs.getFloat(3));
//				dto.setImage(rs.getBlob(4));
//				list.add(dto);
//			}
//			ConnectionUtility.closeConnection(null, null);
//			return list;
//		}
//		catch (Exception e) {
//			ConnectionUtility.closeConnection(e, null);
//			return null;
//		}
//	}
//
////	@Override
////	public int insertShop(ShopDTO<Shop> dto) {
////		PreparedStatement ps;
////		try
////		{
////			Connection con = ConnectionUtility.getConnection();
////			ps = con.prepareStatement("insert into shopcart1");
////		}
////		catch (Exception e) {
////			// TODO: handle exception
////		}
////	}
//
//	@Override
//	public int updateShop(ShopDTO<Shop> dto) {
//		// TODO Auto-generated method stub
//		return 0;
//	}
//
//	@Override
//	public int deleteShop(ShopDTO<Shop> dto) {
//		// TODO Auto-generated method stub
//		return 0;
//	}
//	@Override
//	public int insertShop(ShopDTO<Shop> dto) {
//		// TODO Auto-generated method stub
//		return 0;
//	}
//
//}
