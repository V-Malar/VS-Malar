package dao;

import java.util.List;

import dto.CustomerRegDTO;

public interface CustomerRegDAO {
	public CustomerRegDTO findByID(int uid);
	public List<CustomerRegDTO> findAll();
	public CustomerRegDTO findByName(String customerName);
	public int insertCustomer(CustomerRegDTO dto);
	public int updateCustomer(CustomerRegDTO dto);
	public int deleteCustomer(CustomerRegDTO dto);
}
