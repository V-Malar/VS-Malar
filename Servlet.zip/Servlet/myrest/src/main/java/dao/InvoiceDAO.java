package dao;

import dto.InvoiceDTO;

public interface InvoiceDAO {
	public int insertInvoice(InvoiceDTO dto);
}
