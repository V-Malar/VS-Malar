package dao;

import java.util.List;

import dto.ShopDTO;

public interface ShopDAO<Shop> {
public ShopDTO<Shop> findByName(String name);
public List<ShopDTO<Shop>> findAll();
public int insertShop(ShopDTO<Shop> dto);
public int updateShop(ShopDTO<Shop> dto);
public int deleteShop(ShopDTO<Shop> dto);
}
