package dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.logging.Logger;

import control.ConnectionUtility;
import dto.InvoiceDTO;

public class InvoiceDAOImpl implements InvoiceDAO, Cloneable{
	private static final String CLASS_NAME = CustomerRegDAOImpl.class.getName();
	private static Logger logger=Logger.getLogger(CLASS_NAME);
	public InvoiceDAOImpl() {
		logger.info("InvoiceDAOImpl got executing...");
	}

	private static InvoiceDAOImpl im;
	

	synchronized public static InvoiceDAOImpl getServiceImpl() {
		if (im == null) {
			im = new InvoiceDAOImpl();
			return im;
		} else {
			return im.createClone();
		}
	}

	private InvoiceDAOImpl createClone() {
		try {
			return (InvoiceDAOImpl)super.clone();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public int insertInvoice(InvoiceDTO dto) {
		PreparedStatement ps;
		try {
			Connection con = ConnectionUtility.getConnection();
			ps = con.prepareStatement("insert into invoice_master(c_id,product) values (?,?)");
			dto.init(logger, "INSERTION");
			System.out.println("Here" + dto);
			ps.setInt(1, dto.getC_id());
			ps.setString(2, dto.getProduct());
			ps.executeUpdate();
			con.commit();
			ConnectionUtility.closeConnection(null, null);
		} catch (Exception e) {
			ConnectionUtility.closeConnection(e, null);
			return 0;
		}
		return 1;
	}

}
