package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;

import control.ConnectionUtility;
import dto.CustomerRegDTO;

public class CustomerRegDAOImpl implements CustomerRegDAO, Cloneable {
	public static void main(String[] args) {
		CustomerRegDAO cdao = new CustomerRegDAOImpl();
		CustomerRegDTO dto = new CustomerRegDTO();
		dto.setC_id(Math.abs(UUID.randomUUID().hashCode()));
		dto.setEmail("shinchan@gmail.com");
		dto.setPassword("shinchan");
		dto.setAddress("japan, kasukabe");
		dto.setTele("007");
		dto.setUsername("Shinchan");
		cdao.updateCustomer(dto);
	}
	private static final String CLASS_NAME = CustomerRegDAOImpl.class.getName();
	private static Logger logger=Logger.getLogger(CLASS_NAME);
	public CustomerRegDAOImpl() {
		logger.info("CustomerRegDAOImpl got executing...");
	}

	private static CustomerRegDAOImpl cs;
	

	synchronized public static CustomerRegDAOImpl getServiceImpl() {
		if (cs == null) {
			cs = new CustomerRegDAOImpl();
			return cs;
		} else {
			return cs.createClone();
		}
	}

	private CustomerRegDAOImpl createClone() {
		try {
			return (CustomerRegDAOImpl)super.clone();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CustomerRegDTO findByID(int uid) {
		PreparedStatement ps;
		try {
			Connection con = ConnectionUtility.getConnection();
			ps = con.prepareStatement("select * from customer_master where c_id=?");
			ps.setInt(1, uid);
			ResultSet rs = ps.executeQuery();
			CustomerRegDTO dto = new CustomerRegDTO();
			if (rs.next()) {
				dto.init(logger, "FIND BY ID");
				dto.setC_id(rs.getInt(1));
				dto.setUsername(rs.getString(2));
				dto.setPassword(rs.getString(6));
				dto.setEmail(rs.getString(5));
				dto.setTele(rs.getString(4));
				dto.setAddress(rs.getString(3));
				dto.setFlag(rs.getInt(7));
				
			}
			ConnectionUtility.closeConnection(null, null);
			return dto;
		} catch (Exception e) {
			ConnectionUtility.closeConnection(e, null);
			return null;
		}
	}

	@Override
	public List<CustomerRegDTO> findAll() {
		PreparedStatement ps;
		try {
			Connection con = ConnectionUtility.getConnection();
			ps = con.prepareStatement("select * from customer_master");
			ResultSet rs = ps.executeQuery();
			List<CustomerRegDTO> list = new ArrayList<CustomerRegDTO>();
			while (rs.next()) {
				CustomerRegDTO dto = new CustomerRegDTO();
				dto.init(logger, "VIEW LIST");
				dto.setC_id(rs.getInt(1));
				dto.setUsername(rs.getString(2));
				dto.setPassword(rs.getString(6));
				dto.setEmail(rs.getString(5));
				dto.setTele(rs.getString(4));
				dto.setAddress(rs.getString(3));
				dto.setFlag(rs.getInt(7));
				list.add(dto);
			}
			ConnectionUtility.closeConnection(null, null);
			return list;
		} catch (Exception e) {
			ConnectionUtility.closeConnection(e, null);
			return null;
		}
	}
	@Override
	public CustomerRegDTO findByName(String customerName) {
		PreparedStatement ps;
		try {
			Connection con=ConnectionUtility.getConnection();
			ps = con.prepareStatement("select * from customer_master where c_name=?");
			ps.setString(1, customerName);
			ResultSet rs=ps.executeQuery();
			CustomerRegDTO dto=new CustomerRegDTO();
			if (rs.next()) {
				dto.init(logger, "FIND BY NAME");
				dto.setC_id(rs.getInt(1));
				dto.setUsername(rs.getString(2));
				dto.setPassword(rs.getString(6));
				dto.setEmail(rs.getString(5));
				dto.setTele(rs.getString(4));
				dto.setAddress(rs.getString(3));
				dto.setFlag(rs.getInt(7));
				//System.out.println(dto);
			}
			else {
				return null;
			}
			ConnectionUtility.closeConnection(null, null);
			return dto;			
		}catch(Exception e) {
			ConnectionUtility.closeConnection(e, null);
			return null;
		}
		
	}
	
	@Override
	public int insertCustomer(CustomerRegDTO dto) {
		PreparedStatement ps;
		try {
			Connection con = ConnectionUtility.getConnection();
			ps = con.prepareStatement("insert into customer_master values (?,?,?,?,?,?,?)");
			dto.init(logger, "INSERTION");
			ps.setInt(1, dto.getC_id());
			ps.setString(2, dto.getUsername());
			ps.setString(3, dto.getAddress());
			ps.setString(4, dto.getTele());
			ps.setString(5, dto.getEmail());
			ps.setString(6, dto.getPassword());
			ps.setInt(7, dto.getFlag());
			ps.executeUpdate();
			con.commit();
			ConnectionUtility.closeConnection(null, null);
		} catch (Exception e) {
			ConnectionUtility.closeConnection(e, null);
			return 0;
		}
		return 1;
	}

	@Override
	public int updateCustomer(CustomerRegDTO dto) {
		PreparedStatement ps;
		try {
			Connection con = ConnectionUtility.getConnection();
			ps = con.prepareStatement("select * from customer_master where c_name=?");
			ps.setString(1, dto.getUsername());
			//System.out.println(dto.getUsername());
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				ps = con.prepareStatement("update customer_master set c_id=?, c_name=?, c_addr=?, c_tele=?, c_email=?, c_pwd=?, flag=? where c_name=?");
				dto.init(logger, "UPDATION");
				ps.setInt(1, dto.getC_id());
				ps.setString(2,dto.getUsername());
				ps.setString(3, dto.getAddress());
				ps.setString(4, dto.getTele());
				ps.setString(5, dto.getEmail());
				ps.setString(6, dto.getPassword());
				ps.setInt(7, dto.getFlag());
				ps.setString(8, dto.getUsername());
				//System.out.println(ps);
				ps.executeUpdate();
			} else {
				System.out.println("no record found to update....");
			}
			ConnectionUtility.closeConnection(null, null);
		} catch (Exception e) {
			ConnectionUtility.closeConnection(e, null);
			return 0;
		}
		return 1;
	}

	@Override
	public int deleteCustomer(CustomerRegDTO dto) {
		PreparedStatement ps;
		try {
			Connection con = ConnectionUtility.getConnection();
			ps = con.prepareStatement("delete from customer_master where c_email=?");
			dto.init(logger, "DELETION");
			ps.setString(5, dto.getEmail());
			ps.executeUpdate();
			ConnectionUtility.closeConnection(null, null);
		} catch (Exception e) {
			ConnectionUtility.closeConnection(e, null);
			return 0;
		}
		return 1;
	}

}
