package dto;

import java.util.Objects;
import java.util.logging.Logger;

public class CustomerRegDTO {
	private String email, username, password, address, tele;
	private int flag, c_id;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getTele() {
		return tele;
	}
	public void setTele(String tele) {
		this.tele = tele;
	}
	public int getFlag() {
		return flag;
	}
	public void setFlag(int flag) {
		this.flag = flag;
	}
	public int getC_id() {
		return c_id;
	}
	public void setC_id(int c_id) {
		this.c_id = c_id;
	}
	@Override
	public int hashCode() {
		return Objects.hash(c_id);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerRegDTO other = (CustomerRegDTO) obj;
		return c_id == other.c_id;
	}
	@Override
	public String toString() {
		return "CustomerRegDTO [email=" + email + ", username=" + username + ", password=" + password + ", address="
				+ address + ", tele=" + tele + ", flag=" + flag + ", c_id=" + c_id + "]";
	}

	public void init(Logger log, String msg)
	{
		log.info("DTO executing on " + msg);
	}
}
