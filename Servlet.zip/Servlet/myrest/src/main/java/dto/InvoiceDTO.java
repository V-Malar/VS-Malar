package dto;

import java.util.logging.Logger;

public class InvoiceDTO {
	int c_id; String product;

	public int getC_id() {
		return c_id;
	}

	public void setC_id(int c_id) {
		this.c_id = c_id;
	}


	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "InvoiceDTO [c_id=" + c_id + ", product=" + product + "]";
	}

	public void init(Logger log, String msg)
	{
		log.info("DTO executing on " + msg);
	}
}
