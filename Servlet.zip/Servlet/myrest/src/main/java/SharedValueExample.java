public class SharedValueExample {
    private static ThreadLocal<StringBuilder> threadLocal = ThreadLocal.withInitial(() -> new StringBuilder());

    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
            Thread thread = new Thread(() -> {
                StringBuilder sb = threadLocal.get();
                sb.append(Thread.currentThread().getId());
                System.out.println(sb.toString());
            });
            thread.start();
        }

        // Sleep to allow the threads to complete their work.
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // At this point, the threads have completed, but the ThreadLocal values are not cleaned up.
        // Since the ThreadLocal instances are long-lived, they will still hold references to the StringBuilder objects.
        // This can lead to a memory leak if not properly cleaned up.

        // Attempting to clean up the ThreadLocal instances
        threadLocal.remove();

        // After removing the ThreadLocal instances, they should be eligible for garbage collection.
    }
}