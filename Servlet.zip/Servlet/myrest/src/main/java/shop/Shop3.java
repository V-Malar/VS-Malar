package shop;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import control.ConnectionUtility;
import dao.ShopDAO;
import dto.ShopDTO;

public class Shop3 extends Shop implements ShopDAO<Shop3>, Cloneable{

	@Override
	public ShopDTO<Shop3> findByName(String name) {
		PreparedStatement ps;
		try {
			Connection con = ConnectionUtility.getConnection();
			ps = con.prepareStatement("select * from shopcart3 where item_name = ?");
			ps.setString(1, name);
			ResultSet rs = ps.executeQuery();
			ShopDTO<Shop3> dto = new ShopDTO<Shop3>();
			if (rs.next()) {
				dto.setShopid(rs.getInt(1));
				dto.setItem_name(rs.getString(2));
				dto.setPrice(rs.getFloat(3));
				dto.setImage(rs.getString(4));
				dto.setStock(rs.getInt(5));
				System.out.println(dto);
			} else {
				return null;
			}
			ConnectionUtility.closeConnection(null, null);
			return dto;
		} catch (Exception e) {
			ConnectionUtility.closeConnection(e, null);
			return null;
		}
	}
private static Shop3 cs;
	

	synchronized public static Shop3 getServiceImpl() {
		if (cs == null) {
			cs = new Shop3();
			return cs;
		} else {
			return cs.createClone();
		}
	}

	private Shop3 createClone() {
		try {
			return (Shop3)super.clone();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<ShopDTO<Shop3>> findAll() {
		PreparedStatement ps;
		try
		{
			Connection con = ConnectionUtility.getConnection();
			ps = con.prepareStatement("select * from shopcart3");
			ResultSet rs = ps.executeQuery();
			List<ShopDTO<Shop3>> list = new ArrayList<ShopDTO<Shop3>>();
			while (rs.next())
			{
				ShopDTO<Shop3> dto = new ShopDTO<Shop3>();
				dto.setShopid(rs.getInt(1));
				dto.setItem_name(rs.getString(2));
				dto.setPrice(rs.getFloat(3));
				dto.setImage(rs.getString(4));
				list.add(dto);
			}
			ConnectionUtility.closeConnection(null, null);
			return list;
		}
		catch (Exception e) {
			ConnectionUtility.closeConnection(e, null);
			return null;
		}
	}

	@Override
	public int insertShop(ShopDTO<Shop3> dto) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateShop(ShopDTO<Shop3> dto) {
		PreparedStatement ps;
		try {
			Connection con = ConnectionUtility.getConnection();
			ps = con.prepareStatement("select * from shopcart3 where item_name=?");
			ps.setString(1, dto.getItem_name());
			// System.out.println(dto.getUsername());
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				ps = con.prepareStatement(
						"update shopcart3 set shopid=?, item_name=?, price=?, image=?, stock=? where item_name=?");
				ps.setInt(1, dto.getShopid());
				ps.setString(2, dto.getItem_name());
				ps.setFloat(3, dto.getPrice());
				ps.setString(4, dto.getImage());
				ps.setLong(5, dto.getStock());
				ps.setString(6, dto.getItem_name());
				// System.out.println(ps);
				ps.executeUpdate();
			} else {
				System.out.println("no record found to update....");
			}
			ConnectionUtility.closeConnection(null, null);
		} catch (Exception e) {
			ConnectionUtility.closeConnection(e, null);
			return 0;
		}
		return 1;
	}

	@Override
	public int deleteShop(ShopDTO<Shop3> dto) {
		// TODO Auto-generated method stub
		return 0;
	}

}
