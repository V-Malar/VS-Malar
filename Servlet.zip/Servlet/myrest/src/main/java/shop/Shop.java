package shop;

public class Shop {
	
}
