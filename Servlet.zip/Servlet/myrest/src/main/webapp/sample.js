// scriptfruit.js
// Define the URL of the RESTful service
const apiUrl1 = 'http://localhost:8081/myrest/rest/shop/shop1'; // Replace with your API URL
// Make a GET request to the API
fetch(apiUrl1, { mode: 'no-cors' })
	.then(response => {
		if (!response.ok) {
			throw new Error('Network response was not ok');
		}
		return response.json(); // Parse the response as JSON
	})
	.then(data => {
		// Handle the data received from the API
		console.log('Data from the API:', data);
		// You can perform further processing here
		console.log(data.length);

		for (var i = 0; i < data.length; i++) {
			var image = new Image();
			var div = document.createElement("div");
			var name = document.createElement("label");
			var price = document.createElement("label");
			var br = document.createElement("br");
			var checkbox = document.createElement("input");
			var count = document.createElement("input");

			div.setAttribute("id", "div"+i);
			div.setAttribute("name", "div");
			image.src = data[i].image;
			name.innerHTML = data[i].item_name;
			price.innerHTML = data[i].price;
			image.setAttribute("id", "img");
			name.setAttribute("id", "mark");
			price.setAttribute("id", "price");
			checkbox.setAttribute("type", "checkbox");
			count.setAttribute("type", "number");
			checkbox.setAttribute("id", data[i].item_name);
			checkbox.setAttribute("value", data[i].price);
			checkbox.setAttribute("name", "fruits");
			count.setAttribute("name", data[i].item_name);
			count.setAttribute("id", "count");

			//document.body.appendChild(div);
			div.appendChild(image);
			div.appendChild(name);
			div.appendChild(price);
			div.appendChild(br);
			div.appendChild(checkbox);
			div.appendChild(count);
			document.getElementById("imagehere1").appendChild(div);

			console.log(image.src);
			var sections = document.querySelectorAll("section");
			console.log(sections.length);
		}
	})
	.catch(error => {
		console.error('Fetch error: ', error);
	});
function GetSelected1() {
	var selected = [];
	var fruits = document.querySelectorAll('input[name="fruits"]');
	var countcheck = document.querySelectorAll('input[id="count"]');
	var div = document.querySelectorAll("div.div");


	//console.log("Fruits: " + fruits.length);
	//console.log("Count: " + countcheck.length);
	console.log("Div: " + div.length);
	var total = 0;
	var total1 = 0;

	for (let i = 0; i < fruits.length; i++) {
		if (fruits[i].checked) {
			selected.push(fruits[i].id, countcheck[i].value);
			total += parseInt(fruits[i].value) * parseInt(Math.round(countcheck[i].value));
			if (parseInt(Math.round(countcheck[i].value)) > 0) {
				let add = document.createElement("input");
				let tag = document.createElement("input");
				var submit = document.createElement("button");
				let form = document.createElement("form");

				tag.setAttribute("name", "product");
				tag.setAttribute("value", fruits[i].id);
				tag.setAttribute("id", fruits[i].id);
				tag.setAttribute("type", "hidden");
				add.setAttribute("name", "count");
				add.setAttribute("value", countcheck[i].value);
				add.setAttribute("type", "hidden");
				form.setAttribute("id", "form" + i);
				form.setAttribute("method", "POST");
				form.setAttribute("action", "submit");
				submit.setAttribute("id", "submit" + i);
				submit.setAttribute("name", "submit");
				submit.innerHTML = "ADD TO CART - " + tag.getAttribute("id");

				// console.log(`"${fruits[0].id}"`);
				// console.log("ID: " + div[i]);
				document.getElementById("div"+i).appendChild(form);
				//document.getElementById("form" + i).appendChild(submit);

				console.log(tag);
				console.log(add);
				console.log(submit);

				console.log(fruits[0].id);

				document.getElementById("form" + i).appendChild(tag);
				document.getElementById("form" + i).appendChild(add);
				document.getElementById("form" + i).appendChild(submit);
				document.getElementById("invoiceitems").innerHTML += "<td>" + tag.getAttribute("id") + "</td><td>" + fruits[i].value + "</td><td>" + add.getAttribute("value") + "</td>";

				document.getElementById("submit" + i).addEventListener("click", function() {

					// Get a reference to the form element
					const form = document.getElementById('form' + i);

					// Add a submit event listener to the form

					form.addEventListener('submit', function(event) {
						document.getElementById("submit" + i).style.display = "none";
						alert("Added successfully...");
						document.getElementById("invoice").style.display = "block";
						event.preventDefault(); // Prevent the default form submission
						// Get form data as a FormData object
						const formData1 = new FormData(form);
						const formData = new URLSearchParams();

						form.parentNode.removeChild(form);

						for (const [field, value] of formData1) {
							console.log("Here:" + `${field}: ${value}`);
							formData.append(field, value);
						}

						//Define the URL of the RESTful endpoint
						const apiUrl = "http://localhost:8081/myrest/rest/shop/updatefruitshoppingcart";

						// Make a POST request to the API with the form data
						fetch(apiUrl, {
							method: 'POST',
							body: formData,
							headers: {
								'Content-Type': 'application/x-www-form-urlencoded',
							},
							mode: 'no-cors'
						})
							.then(response => {
								if (!response.ok) {
									throw new Error('Network response was not ok');
								}
								return response.text();
								// return response.json(); // Parse the response as JSON
							})
							.then(data => {
								// Handle the response data from the API
								console.log('Response data:', data);
								// You can perform further processing here
								document.getElementById("cart").style.display = "block";
							})
							.catch(error => {
								// Handle any errors that occured during the fetch
								console.log('Fetch error:', error);
							});
					});
				})
				console.log(document.getElementById('form' + i));
				console.log(tag);
				console.log(add);
			}
			total1 += total;
		}
		fruits[i].checked = false;
		countcheck[i].value = "";
	}

	console.log(total1);
	// document.getElementById("total").innerHTML = "Total: " + total1;
	document.getElementById("amount").innerHTML = parseInt(document.getElementById("amount").innerHTML) + total;

	function newFunction() {
		return "+fruits[0].id+\"+";
	}
}





// scriptfruit.js
// Define the URL of the RESTful service
const apiUrl1 = 'http://localhost:8081/myrest/rest/shop/shop1'; // Replace with your API URL
// Make a GET request to the API
fetch(apiUrl1, { mode: 'no-cors' })
	.then(response => {
		if (!response.ok) {
			throw new Error('Network response was not ok');
		}
		return response.json(); // Parse the response as JSON
	})
	.then(data => {
		// Handle the data received from the API
		console.log('Data from the API:', data);
		// You can perform further processing here
		console.log(data.length);

		for (var i = 0; i < data.length; i++) {
			var image = new Image();
			var div = document.createElement("div");
			var name = document.createElement("label");
			var price = document.createElement("label");
			var br = document.createElement("br");
			var checkbox = document.createElement("input");
			var count = document.createElement("input");

			div.setAttribute("id", "div" + i);
			div.setAttribute("name", "div");
			image.src = data[i].image;
			name.innerHTML = data[i].item_name;
			price.innerHTML = data[i].price;
			image.setAttribute("id", "img");
			name.setAttribute("id", "mark");
			price.setAttribute("id", "price");
			checkbox.setAttribute("type", "checkbox");
			count.setAttribute("type", "number");
			checkbox.setAttribute("id", data[i].item_name);
			checkbox.setAttribute("value", data[i].price);
			checkbox.setAttribute("name", "fruits");
			count.setAttribute("name", data[i].item_name);
			count.setAttribute("id", "count");

			//document.body.appendChild(div);
			div.appendChild(image);
			div.appendChild(name);
			div.appendChild(price);
			div.appendChild(br);
			div.appendChild(checkbox);
			div.appendChild(count);
			document.getElementById("imagehere1").appendChild(div);

			console.log(image.src);
			var sections = document.querySelectorAll("section");
			console.log(sections.length);
		}
	})
	.catch(error => {
		console.error('Fetch error: ', error);
	});
// function GetSelected1() {
var selected = [];
var fruits = document.querySelectorAll("input[type='checkbox']");
var countcheck = document.querySelectorAll('input[id="count"]');
var div = document.querySelectorAll("div.div");


//console.log("Fruits: " + fruits.length);
//console.log("Count: " + countcheck.length);
console.log("Div: " + div.length);
var total = 0;
var total1 = 0;

for (let i = 0; i < fruits.length; i++) {
	fruits[i].addEventListener('click', GetSelected1);
	console.log(fruits[i]);
}
function GetSelected1(e) {
	if (e.target.checked) {
		alert("You checked");
		selected.push(fruits[i].id, countcheck[i].value);
		total += parseInt(fruits[i].value) * parseInt(Math.round(countcheck[i].value));
		// if (parseInt(Math.round(countcheck[i].value)) > 0) {
			let add = document.createElement("input");
			let tag = document.createElement("input");
			var submit = document.createElement("button");
			let form = document.createElement("form");

			tag.setAttribute("name", "product");
			tag.setAttribute("value", fruits[i].id);
			tag.setAttribute("id", fruits[i].id);
			tag.setAttribute("type", "hidden");
			add.setAttribute("name", "count");
			add.setAttribute("value", countcheck[i].value);
			add.setAttribute("type", "hidden");
			form.setAttribute("id", "form" + i);
			form.setAttribute("method", "POST");
			form.setAttribute("action", "submit");
			submit.setAttribute("id", "submit" + i);
			submit.setAttribute("name", "submit");
			submit.innerHTML = "ADD TO CART - " + tag.getAttribute("id");
			document.getElementById("form" + i).appendChild(submit);

			// console.log(`"${fruits[0].id}"`);
			// console.log("ID: " + div[i]);
			document.getElementById("div" + i).appendChild(form);
			//document.getElementById("form" + i).appendChild(submit);

			console.log(tag);
			console.log(add);
			console.log(submit);

			console.log(fruits[0].id);

			document.getElementById("form" + i).appendChild(tag);
			document.getElementById("form" + i).appendChild(add);
			document.getElementById("invoiceitems").innerHTML += "<td>" + tag.getAttribute("id") + "</td><td>" + fruits[i].value + "</td><td>" + add.getAttribute("value") + "</td>";

			document.getElementById("submit" + i).addEventListener("click", function() {

				// Get a reference to the form element
				const form = document.getElementById('form' + i);

				// Add a submit event listener to the form

				form.addEventListener('submit', function(event) {
					document.getElementById("submit" + i).style.display = "none";
					alert("Added successfully...");
					document.getElementById("invoice").style.display = "block";
					event.preventDefault(); // Prevent the default form submission
					// Get form data as a FormData object
					const formData1 = new FormData(form);
					const formData = new URLSearchParams();

					form.parentNode.removeChild(form);

					for (const [field, value] of formData1) {
						console.log("Here:" + `${field}: ${value}`);
						formData.append(field, value);
					}

					//Define the URL of the RESTful endpoint
					const apiUrl = "http://localhost:8081/myrest/rest/shop/updatefruitshoppingcart";

					// Make a POST request to the API with the form data
					fetch(apiUrl, {
						method: 'POST',
						body: formData,
						headers: {
							'Content-Type': 'application/x-www-form-urlencoded',
						},
						mode: 'no-cors'
					})
						.then(response => {
							if (!response.ok) {
								throw new Error('Network response was not ok');
							}
							return response.text();
							// return response.json(); // Parse the response as JSON
						})
						.then(data => {
							// Handle the response data from the API
							console.log('Response data:', data);
							// You can perform further processing here
							document.getElementById("cart").style.display = "block";
						})
						.catch(error => {
							// Handle any errors that occured during the fetch
							console.log('Fetch error:', error);
						});
				});
			})
			console.log(document.getElementById('form' + i));
			console.log(tag);
			console.log(add);
		//}
		total1 += total;
	}
	fruits[i].checked = false;
	countcheck[i].value = "";
}

console.log(total1);
// document.getElementById("total").innerHTML = "Total: " + total1;
//document.getElementById("amount").innerHTML = parseInt(document.getElementById("amount").innerHTML) + total;

function newFunction() {
	return "+fruits[0].id+\"+";
}
// }








// scriptfruit.js
// Define the URL of the RESTful service
const apiUrl2 = 'http://localhost:8081/myrest/rest/shop/shop2'; // Replace with your API URL
// Make a GET request to the API
fetch(apiUrl2, { mode: 'no-cors' })
	.then(response => {
		if (!response.ok) {
			throw new Error('Network response was not ok');
		}
		return response.json(); // Parse the response as JSON
	})
	.then(data => {
		// Handle the data received from the API
		console.log('Data from the API:', data);
		// You can perform further processing here
		console.log(data.length);

		for (var i = 0; i < data.length; i++) {
			var image = new Image();
			var div = document.createElement("div");
			var name = document.createElement("label");
			var price = document.createElement("label");
			var br = document.createElement("br");
			var checkbox = document.createElement("input");
			var count = document.createElement("input");

			div.setAttribute("name", "div");
			image.src = data[i].image;
			name.innerHTML = data[i].item_name;
			price.innerHTML = data[i].price;
			image.setAttribute("id", "img");
			name.setAttribute("id", "mark");
			price.setAttribute("id", "price");
			checkbox.setAttribute("type", "checkbox");
			count.setAttribute("type", "number");
			checkbox.setAttribute("id", data[i].item_name);
			checkbox.setAttribute("value", data[i].price);
			checkbox.setAttribute("name", "vegetables");
			count.setAttribute("name", data[i].item_name);
			count.setAttribute("id", "count");

			//document.body.appendChild(div);
			div.appendChild(image);
			div.appendChild(name);
			div.appendChild(price);
			div.appendChild(br);
			div.appendChild(checkbox);
			div.appendChild(count);
			document.getElementById("imagehere2").appendChild(div);
		}
	})
	.catch(error => {
		console.error('Fetch error: ', error);
	});
function GetSelected2() {
	var selected = [];
	var vegetables = document.querySelectorAll("input[name='vegetables']");
	var countcheck = document.querySelectorAll('input[id="count"]');
	var div = document.querySelectorAll("div.div");


	//console.log("vegetables: " + vegetables.length);
	//console.log("Count: " + countcheck.length);
	console.log("Div: " + div.length);
	var total = 0;
	var total1 = 0;

	for (let i = 0; i < vegetables.length; i++) {
		countcheck[i].addEventListener('blur', function(e) {			
				let fruit = vegetables[i].id;
				price = vegetables[i].value;
				GetSelectedF(e, price, fruit, i);
			});
		console.log(vegetables[i]);
	}
	function GetSelectedF(e, val, name, i) {
		if (val > 0) {
			console.log("Here..");
			//alert("Count: " + e.target.value);
			//e.target.checked = true;
			selected.push(e.target.id, val);
			console.log(e + " " + val + " " + i);
			total += parseInt(e.target.value) * parseInt(Math.round(val));
			console.log("Your Total: " + total);
			// if (parseInt(Math.round(countcheck[i].value)) > 0) {
			let add = document.createElement("input");
			let tag = document.createElement("input");
			var submit = document.createElement("button");
			let form = document.createElement("form");

			tag.setAttribute("name", "product");
			tag.setAttribute("value", name);
			tag.setAttribute("id", name);
			tag.setAttribute("type", "hidden");
			add.setAttribute("name", "count");
			add.setAttribute("value", e.target.value);
			add.setAttribute("type", "hidden");
			form.setAttribute("id", "form" + i);
			form.setAttribute("method", "POST");
			form.setAttribute("action", "submit");
			submit.setAttribute("id", "submit" + i);
			submit.setAttribute("name", "submit");
			submit.innerHTML = "ADD TO CART - " + tag.getAttribute("id");

			// console.log(`"${vegetables[0].id}"`);
			// console.log("ID: " + div[i]);
			console.log(form.getAttribute("id"));
			form.appendChild(tag);
			form.appendChild(add);
			form.appendChild(submit);
			console.log(form);
			console.log(i);
			console.log(div);
			//div.appendChild(form);
			countcheck[i].parentNode.insertBefore(form, countcheck[i].nextSibling);
			//document.getElementById("form" + i).appendChild(submit);

			console.log(tag);
			console.log(add);
			console.log(submit);

			console.log(vegetables[0].id);

			
			document.getElementById("invoiceitems").innerHTML += "<td>" + tag.getAttribute("id") + "</td><td>" + e.target.value + "</td><td>" + add.getAttribute("value") + "</td>";

			document.getElementById("submit" + i).addEventListener("click", function() {

				// Get a reference to the form element
				const form = document.getElementById('form' + i);

				// Add a submit event listener to the form

				form.addEventListener('submit', function(event) {
					document.getElementById("submit" + i).style.display = "none";
					alert("Added successfully...");
					document.getElementById("invoice").style.display = "block";
					event.preventDefault(); // Prevent the default form submission
					// Get form data as a FormData object
					const formData1 = new FormData(form);
					const formData = new URLSearchParams();

					form.parentNode.removeChild(form);

					for (const [field, value] of formData1) {
						console.log("Here:" + `${field}: ${value}`);
						formData.append(field, value);
					}

					//Define the URL of the RESTful endpoint
					const apiUrl = "http://localhost:8081/myrest/rest/shop/updatevegetableshoppingcart";

					// Make a POST request to the API with the form data
					fetch(apiUrl, {
						method: 'POST',
						body: formData,
						headers: {
							'Content-Type': 'application/x-www-form-urlencoded',
						},
						mode: 'no-cors'
					})
						.then(response => {
							if (!response.ok) {
								throw new Error('Network response was not ok');
							}
							return response.text();
							// return response.json(); // Parse the response as JSON
						})
						.then(data => {
							// Handle the response data from the API
							console.log('Response data:', data);
							// You can perform further processing here
							document.getElementById("cart").style.display = "block";
						})
						.catch(error => {
							// Handle any errors that occured during the fetch
							console.log('Fetch error:', error);
						});
				});
			})
			console.log(document.getElementById('form' + i));
			console.log(tag);
			console.log(add);
			//}
			total1 += total;
		}
		vegetables[i].checked = false;
		countcheck[i].value = "";
		document.getElementById("amount").innerHTML = parseInt(document.getElementById("amount").innerHTML) + total;
	}

	console.log(total1);
	// document.getElementById("total").innerHTML = "Total: " + total1;


	function newFunction() {
		return "+vegetables[0].id+\"+";
	}
}


