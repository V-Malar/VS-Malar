document.addEventListener('DOMContentLoaded', function()
{
	// Get a reference to the form element
	const form = document.getElementById('myRegister');
	// Add a submit event listener to the form
	form.addEventListener('submit', function(event)
	{
		event.preventDefault(); // Prevent the default form submission
		// Get form data as a FormData object
		const formData1 = new FormData(form);
		const formData = new URLSearchParams();
		
		for (const [field, value] of formData1)
		{
			console.log(`${field}: ${value}`);
			formData.append(field, value);
		}
		//Define the URL of the RESTful endpoint
		const apiUrl = 'http://localhost:8080/myrest/rest/shop/register';
		// Make a POST request to the API with the form data
		
		fetch(apiUrl, {
			method: 'POST',
			body: formData,
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded',
			},
			mode: 'no-cors'
		})
		.then(response => {
			if (!response.ok){
				throw new Error('Network response was not ok');
			}
			return response.text();
			// return response.json(); // Parse the response as JSON
		})
		.then(data => {
			// Handle the response data from the API
			console.log('Response data:', data);
			// You can perform further processing here
			if (data == "lang.success")
			{
				document.getElementById("registerdisplay").style.display = "none";
				document.getElementById("logindisplay").style.display = "block";
			}
		})
		.catch(error => {
			// Handle any errors that occured during the fetch
			console.log('Fetch error:', error);
		});
	});
});