document.addEventListener('DOMContentLoaded', function()
{
	// Get a reference to the form element
	const form = document.getElementById('myLogin');
	// Add a submit event listener to the form
	document.getElementById('login').addEventListener('click', function(event)
	{
		event.preventDefault(); // Prevent the default form submission
		//document.getElementById("logindisplay").style.display = "none";
		//document.getElementById("logout").style.display = "block";
		// Get form data as a FormData object
		const formData1 = new FormData(form);
		const formData = new URLSearchParams();
		
		for (const [field, value] of formData1)
		{
			console.log(`${field}: ${value}`);
			formData.append(field, value);
		}
		//Define the URL of the RESTful endpoint
		const apiUrl = 'http://localhost:8080/myrest/rest/shop/login';
		// Make a POST request to the API with the form data
		
		fetch(apiUrl, {
			method: 'POST',
			body: formData,
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded',
			},
			mode: 'no-cors'
		})
		.then(response => {
			if (!response.ok){
				throw new Error('Network response was not ok');
			}
			return response.text();
			// return response.json(); // Parse the response as JSON
		})
		.then(data => {
			// Handle the response data from the API
			console.log('Response data:', data);
			document.getElementById("gotit").innerHTML = data;
			if (data == "login.alreadylogedin")
			{
				console.log(true);
				document.getElementById("logout").style.display = "block";
				//document.getElementById("logindisplay").style.display = "block";
			}
			if (data == "login.success")
			{
				console.log(true);
				document.getElementById("menu").style.display = "block";
				document.getElementById("logout").style.display = "block";
				
			}
			if (data == "login.register")
			{
				console.log(true);
				document.getElementById("logout").style.display = "none";
				document.getElementById("registerdisplay").style.display = "block";
				document.getElementById("logindisplay").style.display = "none";
				document.getElementById("menu").style.display = "none";
			}
			// You can perform further processing here
		})
		.catch(error => {
			// Handle any errors that occured during the fetch
			console.log('Fetch error:', error);
		});
	});
});