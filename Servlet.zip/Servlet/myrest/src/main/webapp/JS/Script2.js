// Define the URL of the RESTful service
const apiUrl2 = 'http://localhost:8080/myrest/rest/shop/shop2'; // Replace with your API URL
// Make a GET request to the API
fetch(apiUrl2, { mode: 'no-cors' })
	.then(response => {
		if (!response.ok) {
			throw new Error('Network response was not ok');
		}
		return response.json(); // Parse the response as JSON
	})
	.then(data => {
		// Handle the data received from the API
		console.log('Data from the API:', data);
		// You can perform further processing here
		console.log(data.length);

		for (var i = 0; i < data.length; i++) {
			let image = new Image();
			let name = document.createElement("label");
			let price = document.createElement("label");
			let br = document.createElement("br");
			var checkbox = document.createElement("input");
			var count = document.createElement("input");

			image.src = data[i].image;
			name.innerHTML = data[i].item_name;
			price.innerHTML = data[i].price;
			image.setAttribute("id", "img");
			name.setAttribute("id", "mark");
			price.setAttribute("id", "price");
			checkbox.setAttribute("type", "checkbox");
			count.setAttribute("type", "number");
			checkbox.setAttribute("id", "fruit" + i);
			checkbox.setAttribute("value", data[i].price);
			checkbox.setAttribute("name", "fruits");
			count.setAttribute("name", "count");
			count.setAttribute("id", "count");


			document.getElementById("imagehere2").appendChild(image);
			document.getElementById("imagehere2").appendChild(name);
			// document.getElementById("imagehere2").appendChild(br);
			document.getElementById("imagehere2").appendChild(price);
			document.getElementById("imagehere2").appendChild(br);
			document.getElementById("imagehere2").appendChild(checkbox);
			document.getElementById("imagehere2").appendChild(count);
			console.log(image.src);
			var sections = document.querySelectorAll("section");
			console.log(sections.length);
		}
	})
	.catch(error => {
		console.error('Fetch error: ', error);
	});
function GetSelected2() {
	var selected = new Array();
	var fruits = document.querySelectorAll('input[name="fruits"]');
	var countcheck = document.querySelectorAll('input[name="count"]');
	console.log("Fruits: " + fruits.length);
	console.log("Count: " + countcheck.length);
	var total = 0;
	var total2 = 0;
	for (let i = 0; i < fruits.length; i++) {
		if (fruits[i].checked) {
			selected.push(fruits[i].value);
			total2 = parseInt(fruits[i].value) * parseInt(Math.round(countcheck[i].value));
						total += parseInt(fruits[i].value) * parseInt(Math.round(countcheck[i].value));
		}
	}
	console.log(total);
	document.getElementById("total").innerHTML = "Total: " + total;
	//document.getElementById("get2").innerHTML += parseInt(total)+ parseInt(document.getElementById("get1").value);
	//if (selected.length > 0) {
	// alert("Selected values: " + selected.join(","));
	//}
}
