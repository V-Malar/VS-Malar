
function selectOnlyThisFruit(id)
{
	for (let i = 1; i<4; i++)
	{
		document.getElementById("imagehere" + i).style.display = "none";
	}
	document.getElementById(id + 1).style.display = "flex";
}
function selectOnlyThisVeg(id)
{
	for (let i = 1; i<4; i++)
	{
		document.getElementById("imagehere" + i).style.display = "none";
	}
	document.getElementById(id + 2).style.display = "flex";
}
function selectOnlyThisNut(id)
{
	for (let i = 1; i<4; i++)
	{
		document.getElementById("imagehere" + i).style.display = "none";
	}
	document.getElementById(id + 3).style.display = "flex";
}