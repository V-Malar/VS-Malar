// Define the URL of the RESTful service
const apiUrl3 = 'http://localhost:8080/myrest/rest/shop/shop3'; // Replace with your API URL
// Make a GET request to the API
fetch(apiUrl3, { mode: 'no-cors' })
	.then(response => {
		if (!response.ok) {
			throw new Error('Network response was not ok');
		}
		return response.json(); // Parse the response as JSON
	})
	.then(data => {
		// Handle the data received from the API
		console.log('Data from the API:', data);
		// You can perform further processing here
		console.log(data.length);

		for (var i = 0; i < data.length; i++) {
			let image = new Image();
			let name = document.createElement("label");
			let price = document.createElement("label");
			let br = document.createElement("br");
			var checkbox = document.createElement("input");
			var count = document.createElement("input");

			image.src = data[i].image;
			name.innerHTML = data[i].item_name;
			price.innerHTML = data[i].price;
			image.setAttribute("id", "img");
			name.setAttribute("id", "mark");
			price.setAttribute("id", "price");
			checkbox.setAttribute("type", "checkbox");
			count.setAttribute("type", "number");
			checkbox.setAttribute("id", "fruit" + i);
			checkbox.setAttribute("value", data[i].price);
			checkbox.setAttribute("name", "fruits");
			count.setAttribute("name", "count");
			count.setAttribute("id", "count");


			document.getElementById("imagehere3").appendChild(image);
			document.getElementById("imagehere3").appendChild(name);
			// document.getElementById("imagehere3").appendChild(br);
			document.getElementById("imagehere3").appendChild(price);
			document.getElementById("imagehere3").appendChild(br);
			document.getElementById("imagehere3").appendChild(checkbox);
			document.getElementById("imagehere3").appendChild(count);
			console.log(image.src);
			var sections = document.querySelectorAll("section");
			console.log(sections.length);
		}
	})
	.catch(error => {
		console.error('Fetch error: ', error);
	});
function GetSelected3() {
	var selected = new Array();
	var fruits = document.querySelectorAll('input[name="fruits"]');
	var countcheck = document.querySelectorAll('input[name="count"]');
	console.log("Fruits: " + fruits.length);
	console.log("Count: " + countcheck.length);
	var total = 0;
	var total3 = 0;
	for (let i = 0; i < fruits.length; i++) {
		if (fruits[i].checked) {
			selected.push(fruits[i].value);
			total3 += parseInt(fruits[i].value) * parseInt(Math.round(countcheck[i].value));
			total += parseInt(fruits[i].value) * parseInt(Math.round(countcheck[i].value));
		}
	}
	console.log(total);
	//document.getElementById("total3").innerHTML = "Nuts Total: " + total3;
	//let amount = document.createElement("label");
	//amount.setAttribute("id", "amount");
	//document.getElementById("imagehere3").appendChild(amount);
	//if (total > 0) {
		//document.getElementById("amount").style.display = "block";
		//document.getElementById("get3").innerHTML = parseInt(total)+ parseInt(document.getElementById("get2").value);
		//document.getElementById("amount").innerHTML = "Total Amount: " + total;
	//}
	//else {
		//document.getElementById("amount").style.display = "none";
	//}
	document.getElementById("total").innerHTML = "Total: " + total;
	//if (selected.length > 0) {
	// alert("Selected values: " + selected.join(","));
	//}
}
