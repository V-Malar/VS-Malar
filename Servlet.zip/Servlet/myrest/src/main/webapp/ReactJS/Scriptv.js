const apiUrl2 = 'http://localhost:8081/myrest/rest/shop/shop2'; // Replace with your API URL
// Make a GET request to the API
fetch(apiUrl2, { mode: 'no-cors' })
	.then(response => {
		if (!response.ok) {
			throw new Error('Network response was not ok');
		}
		return response.json(); // Parse the response as JSON
	})
	.then(data => {
		// Handle the data received from the API
		console.log('Data from the API:', data);
		// You can perform further processing here
		console.log(data.length);

		for (var i = 0; i < data.length; i++) {
			var image = new Image();
			var div = document.createElement("div");
			var name = document.createElement("label");
			var price = document.createElement("label");
			var br = document.createElement("br");
			var checkbox = document.createElement("input");
			var count = document.createElement("input");

			div.setAttribute("id", "div" + i);
			div.setAttribute("name", "div");
			div.setAttribute("class", "gridfruits");
			image.src = data[i].image;
			name.innerHTML = "Product:" + data[i].item_name;
			price.innerHTML = "Price:" + data[i].price;
			image.setAttribute("id", "img");
			name.setAttribute("id", "mark");
			price.setAttribute("id", "price");
			checkbox.setAttribute("type", "checkbox");
			count.setAttribute("type", "number");
			checkbox.setAttribute("id", data[i].item_name);
			checkbox.setAttribute("value", data[i].price);
			checkbox.setAttribute("name", "fruits");
			count.setAttribute("name", data[i].item_name);
			count.setAttribute("id", "count");

			div.appendChild(image);
			div.appendChild(name);
			div.appendChild(price);
			//			div.appendChild(br);
			div.appendChild(checkbox);
			div.appendChild(count);
			document.getElementById("imagehere2").appendChild(div);

			console.log(image.src);
			var sections = document.querySelectorAll("section");
			console.log(sections.length);
		}
	})
	.catch(error => {
		console.error('Fetch error: ', error);
	});
function GetSelected2() {
	var fruits = document.querySelectorAll('input[name="fruits"]');
	var countcheck = document.querySelectorAll('input[id="count"]');

	for (let i = 0; i < fruits.length; i++) {
		if (fruits[i].checked) {
			if (parseInt(Math.round(countcheck[i].value)) > 0) {
				let add = document.createElement("input");
				let tag = document.createElement("input");
				var submit = document.createElement("button");
				let form = document.createElement("form");
				let close = document.createElement("button");

				tag.setAttribute("name", "product");
				tag.setAttribute("value", fruits[i].id);
				tag.setAttribute("id", fruits[i].id);
				tag.setAttribute("type", "hidden");
				add.setAttribute("name", "count");
				add.setAttribute("value", countcheck[i].value);
				add.setAttribute("type", "hidden");
				form.setAttribute("id", "form" + i);
				form.setAttribute("method", "POST");
				form.setAttribute("action", "submit");
				submit.setAttribute("id", "submit" + i);
				submit.setAttribute("name", "submit");
				submit.innerHTML = "ADD TO CART - " + tag.getAttribute("id");
				close.setAttribute("id", "close" + i);
				close.setAttribute("class", "close");
				close.innerHTML = "x";

				countcheck[i].parentNode.insertBefore(form, countcheck[i].nextSibling);

				console.log(tag);
				console.log(add);
				console.log(submit);

				console.log(fruits[0].id);

				close.addEventListener("click", function() {
					alert("Cancelled successfully...");
					form.parentNode.removeChild(form);
					document.getElementById("centeredDiv").classList.remove("hidden");
					const closeButton = document.getElementById("closeButton");
					// Add a click event listener to the close button
					closeButton.addEventListener("click", () => {
						document.getElementById("centeredDiv").classList.add("hidden");
						document.getElementById("overlay").style.display = "none";
					});
					return false;
				});
				form.appendChild(tag);
				form.appendChild(add);
				form.appendChild(submit);
				form.appendChild(close);
				document.getElementById("submit" + i).addEventListener("click", function() {

					// Get a reference to the form element
					const form = document.getElementById('form' + i);

					// Add a submit event listener to the form

					form.addEventListener('submit', function(event) {
						document.getElementById("submit" + i).style.display = "none";
						document.getElementById("centeredDiv").classList.remove("hidden");
						alert("Added successfully...");
						var newRow = document.createElement("tr");

						// Create the first <td> and set its content
						var cell1 = document.createElement("td");
						cell1.textContent = tag.getAttribute("id");

						// Create the second <td> and set its content
						var cell3 = document.createElement("td");
						cell3.textContent = fruits[i].value;

						// Create the third <td> and set its content
						var cell2 = document.createElement("td");
						cell2.textContent = add.getAttribute("value");

						// Append the <td> elements to the new row
						newRow.appendChild(cell1);
						newRow.appendChild(cell2);
						newRow.appendChild(cell3);

						// Get a reference to the table by ID
						var table = document.getElementById("invoiceitems");

						// Get the tbody within the table
						var tableBody = table.querySelector("tbody");

						// Append the new row to the tbody
						tableBody.appendChild(newRow);
						const closeButton = document.getElementById("closeButton");
						// Add a click event listener to the close button
						closeButton.addEventListener("click", () => {
							document.getElementById("centeredDiv").classList.add("hidden");
						});
						amount += parseInt(fruits[i].value) * parseInt(add.getAttribute("value"));
						console.log(amount);
						console.log("Veg:" + amount);

						event.preventDefault(); // Prevent the default form submission
						// Get form data as a FormData object
						const formData1 = new FormData(form);
						const formData = new URLSearchParams();

						form.parentNode.removeChild(form);

						for (const [field, value] of formData1) {
							console.log("Here:" + `${field}: ${value}`);
							formData.append(field, value);
						}

						//Define the URL of the RESTful endpoint
						const apiUrl = "http://localhost:8081/myrest/rest/shop/updatevegetableshoppingcart";

						// Make a POST request to the API with the form data
						fetch(apiUrl, {
							method: 'POST',
							body: formData,
							headers: {
								'Content-Type': 'application/x-www-form-urlencoded',
							},
							mode: 'no-cors'
						})
							.then(response => {
								if (!response.ok) {
									throw new Error('Network response was not ok');
								}
								return response.text();
							})
							.then(data => {
								// Handle the response data from the API
								console.log('Response data:', data);
								// You can perform further processing here
							})
							.catch(error => {
								// Handle any errors that occured during the fetch
								console.log('Fetch error:', error);
							});
					});
				})
			}
		}
		fruits[i].checked = false;
		countcheck[i].value = "";
	}
}

