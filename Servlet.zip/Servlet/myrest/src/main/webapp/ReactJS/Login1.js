//login.js
function login() {
	// Get a reference to the form element
	const form = document.getElementById('myLogin');
	// Add a submit event listener to the form
	document.getElementById('login').addEventListener('click', function(event) {
		event.preventDefault(); // Prevent the default form submission
		//document.getElementById("logindisplay").style.display = "none";
		//document.getElementById("logout").style.display = "initial";
		// Get form data as a FormData object
		const formData1 = new FormData(form);
		const formData = new URLSearchParams();

		for (const [field, value] of formData1) {
			console.log(`${field}: ${value}`);
			formData.append(field, value);
		}
		//Define the URL of the RESTful endpoint
		const apiUrl = 'http://localhost:8081/myrest/rest/shop/login';
		// Make a POST request to the API with the form data

		fetch(apiUrl, {
			method: 'POST',
			body: formData,
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded',
			},
			mode: 'no-cors'
		})
			.then(response => {
				if (!response.ok) {
					throw new Error('Network response was not ok');
				}
				return response.text();
				// return response.json(); // Parse the response as JSON
			})
			.then(data => {
				// Handle the response data from the API
				console.log('Response data:', data);
				// You can perform further processing here
				if (data == "login.alreadylogedin") {
					console.log(true);
					alert("You already logged in..")
					document.getElementById("logout").style.display = "initial";
					//document.getElementById("logindisplay").style.display = "initial";
				}
				if (data == "login.success") {
					console.log(true);
					document.getElementById("menu").style.display = "flex";
					document.getElementById("imagehere1").style.display = "block";
					document.getElementById("he").appendChild(document.getElementById("imagehere1"));
					document.getElementById("displayhere").appendChild(document.getElementById("menu"));
					document.getElementById("logindisplay").style.display = "none";
					document.getElementById("carouselExampleControls").style.display = "none";
					document.getElementById("logout").style.display = "initial";
					//document.getElementById("displayamount").style.display = "none";
					//document.getElementById("invoiceitems").style.display = "none";

				}
				if (data == "login.register") {
					console.log(true);
					document.getElementById("logout").style.display = "none";
					document.getElementById("registerdisplay").style.display = "initial";
					document.getElementById("logindisplay").style.display = "none";
					document.getElementById("carouselExampleControls").style.display = "none";
					document.getElementById("menu").style.display = "none";
				}
			})
			.catch(error => {
				// Handle any errors that occured during the fetch
				console.log('Fetch error:', error);
			});
	});
}
