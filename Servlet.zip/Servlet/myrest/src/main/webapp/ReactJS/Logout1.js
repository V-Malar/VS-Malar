//Logout.js
function logout()
{
	// Get a reference to the form element
	const form = document.getElementById('myLogin');
	// Add a submit event listener to the form
	//document.getElementById("ulogout").innerHTML = document.getElementById("uname").value;
	document.getElementById('logout').addEventListener('click', function()
	{
		location.reload();
		// Get form data as a FormData object
		const formData1 = new FormData(form);
		const formData = new URLSearchParams();
		document.getElementById("logindisplay").style.display = "initial";
		document.getElementById("registerdisplay").style.display = "none";
		document.getElementById("imagehere1").style.display = "none";
		document.getElementById("imagehere2").style.display = "none";
		document.getElementById("imagehere3").style.display = "none";
		
		for (const [field, value] of formData1)
		{
			console.log(`${field}: ${value}`);
			formData.append(field, value);
		}
		//Define the URL of the RESTful endpoint
		const apiUrl = 'http://localhost:8081/myrest/rest/shop/logout';
		// Make a POST request to the API with the form data
		
		fetch(apiUrl, {
			method: 'POST',
			body: formData,
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded',
			},
			mode: 'no-cors'
		})
		.then(response => {
			if (!response.ok){
				throw new Error('Network response was not ok');
			}
			return response.text();
			// return response.json(); // Parse the response as JSON
		})
		.then(data => {
			// Handle the response data from the API
			console.log('Response data:', data);
			// You can perform further processing here
			if (data == "logout.success")
			{
				console.log(true);
				document.getElementById("displayhere").style.display = "none";
				document.getElementById("logindisplay").style.display = "initial";
				document.getElementById("logout").style.display = "none";
				
			}
		})
		.catch(error => {
			// Handle any errors that occured during the fetch
			console.log('Fetch error:', error);
		});
	});
}

