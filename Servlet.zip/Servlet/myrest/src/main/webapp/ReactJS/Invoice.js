
function showInvoice() {
	document.getElementById("menu").style.display = "none";
	document.getElementById("logout").style.display = "block";
	document.getElementById("logindisplay").style.display = "none";
	document.getElementById("amount").style.display = "block";
	document.getElementById("registerdisplay").style.display = "none";
	document.querySelectorAll(".gridproduct").forEach(function(element) {
		element.style.display = "none";
	});
	document.getElementById("google_translate_element").style.display = "none";
	var currentDate = new Date();
	var formattedDate = currentDate.toLocaleDateString();
	document.getElementById("date").innerHTML = "Current Date: " + formattedDate;
	document.getElementById("name").innerHTML = document.getElementById("uname").value;
	var table = document.getElementById("invoiceitems");

	// Get the tbody within the table
	var tableBody = table.querySelector("tbody");

	// Get all rows within the tbody
	var rows = tableBody.querySelectorAll("tr");

	// Iterate through each row
	var result = 0, amount = 0;
	rows.forEach(function(row) {
		// Get the last two <td> elements within the row
		var tds = row.querySelectorAll("td");
		var lastValue = parseFloat(tds[tds.length - 2].textContent);
		var secondLastValue = parseFloat(tds[tds.length - 1].textContent);


		// Check if the values are valid numbers and perform the multiplication
		if (!isNaN(lastValue) && !isNaN(secondLastValue)) {
			result += lastValue * secondLastValue;
		}

	});
	amount = parseFloat(result * (12 / 100)) + result;
	console.log("Result: " + amount);
	//document.getElementById("overlay").style.background = "rgba(0, 0, 10, 0.5)";
	document.getElementById("invoice").style.display = "none";
	document.getElementById("displayamount").style.display = "flex";
	document.getElementById("amount").innerHTML = amount + " (12% GST)";
	document.getElementById("main").style.display = "block";
	document.getElementById("carouselExampleControls").style.display = "block";
}