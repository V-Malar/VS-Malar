function googleTranslateElementInit() {
			new google.translate.TranslateElement(
					{
						pageLanguage : 'en',
						layout : google.translate.TranslateElement.InlineLayout.HORIZONTAL,
						autoDisplay : false,
						includedLanguages : 'fr,de,es,ta,te,hi',
						gaTrack : true,
						gaId : 'YOUR_API_KEY'
					}, 'google_translate_element');
		}