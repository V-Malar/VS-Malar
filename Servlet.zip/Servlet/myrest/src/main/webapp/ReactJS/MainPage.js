//$(document).ready(function() {
// Initialize the carousel
///    $('.carousel').slick({
//      dots: true,
//       autoplay: true,
//      autoplaySpeed: 3000
//   });
//});
function loginShow(e) {
	e.preventDefault();
	document.getElementById("logindisplay").style.display = "block";
	document.getElementById("registerdisplay").style.display = "none";
	document.getElementById("displayhere").appendChild(document.getElementById("logindisplay"));
	document.getElementById("carouselExampleControls").style.display = "none";
		document.getElementById("container").style.display="none";
}

function registerShow(e) {
	e.preventDefault();
	document.getElementById("registerdisplay").style.display = "block";
	document.getElementById("logindisplay").style.display = "none";
	document.getElementById("displayhere").appendChild(document.getElementById("registerdisplay"));
	document.getElementById("carouselExampleControls").style.display = "none";
		document.getElementById("container").style.display="none";
}

function homeShow(e) {
	e.preventDefault();
	document.getElementById("logindisplay").style.display = "none";
	document.getElementById("registerdisplay").style.display = "none";
	document.getElementById("carouselExampleControls").style.display = "block";
		document.getElementById("container").style.display="none";
}

function aboutShow(e) {
	e.preventDefault();
	document.getElementById("registerdisplay").style.display = "none";
	document.getElementById("logindisplay").style.display = "none";
	document.getElementById("container").style.display="block";
	document.getElementById("displayhere").appendChild(document.getElementById("container"));
	document.getElementById("carouselExampleControls").style.display = "none";
}