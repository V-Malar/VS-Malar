// Switch.js

function selectOnlyThisFruit(e) {
	console.log(e.target.getAttribute('id'));
	for (let i = 1; i < 4; i++) {
		document.getElementById("imagehere" + i).style.display = "none";
	}
	document.getElementById(e.target.getAttribute("id") + 1).style.display = "initial";
	console.log(e.target.getAttribute("id") + 1);
	document.getElementById("he").appendChild(document.getElementById(e.target.getAttribute("id") + 1));
}
function selectOnlyThisVeg(e) {
	console.log(e.target.getAttribute('id'));
	for (let i = 1; i < 4; i++) {
		document.getElementById("imagehere" + i).style.display = "none";
	}
	//document.getElementById("menu").style.display = "block";
	document.getElementById(e.target.getAttribute("id") + 2).style.display = "initial";
	document.getElementById("displayhere").appendChild(document.getElementById(e.target.getAttribute("id") + 2));
}
function selectOnlyThisNut(e) {
	for (let i = 1; i < 4; i++) {
		document.getElementById("imagehere" + i).style.display = "none";
	}
	//document.getElementById("menu").style.display = "block";
	document.getElementById(e.target.getAttribute('id') + 3).style.display = "initial";
	document.getElementById("displayhere").appendChild(document.getElementById(e.target.getAttribute('id') + 3));
}

