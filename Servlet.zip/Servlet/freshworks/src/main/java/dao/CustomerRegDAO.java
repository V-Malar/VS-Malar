package dao;

import java.util.List;

public interface CustomerRegDAO {
	public CustomerRegDTO findByID(int uid);
	public List<CustomerRegDTO> findAll();
	public CustomerRegDTO findByName(String customerName);
	public int insertCustomer(CustomerRegDTO dto);
	public int updateCustomer(CustomerRegDTO dto);
	public int deleteCustomer(CustomerRegDTO dto);
}
