package dao;

import java.util.logging.Logger;

public class CustomerRegDTO {
	String email, username, password, address, tele;
	private int flag, c_id;

	public int getFlag() {
		return flag;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}

	public int getC_id() {
		return c_id;
	}

	public void setC_id(int c_id) {
		this.c_id = c_id;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTele() {
		return tele;
	}

	public void setTele(String tele) {
		this.tele = tele;
	}

	int age;

//	@Override
//	public String toString() {
//		return "CustomerRegDTO [email=" + email + ", username=" + username + ", password=" + password + ", address="
//				+ address + ", tele=" + tele + ", age=" + age + ", address: " + address + "]";
//	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	public void init(Logger log, String msg)
	{
		log.info("DTO executing on " + msg);
	}
}
