package service;

import dao.CustomerDAO;
import dao.CustomerDAOImpl;
import dao.CustomerDTO;
import dao.CustomerRegDAO;
import dao.CustomerRegDAOImpl;
import dao.CustomerRegDTO;

public class CustomerServiceImpl implements CustomerService,Cloneable{
	
	private CustomerServiceImpl() {
		//System.out.println("customer service impl object created...");
	}
	
	private static CustomerServiceImpl cs;
	
	synchronized public static CustomerServiceImpl getServiceImpl() {
		if(cs==null) {
			cs=new CustomerServiceImpl();
			return cs;
		}
		else {
			return cs.createClone();
		}
	}
	private CustomerServiceImpl createClone() {
		try {
			return (CustomerServiceImpl)super.clone();
		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	@Override
	public boolean checkFlag(String uname) {
		CustomerRegDAO cdao=CustomerRegDAOImpl.getServiceImpl();
		CustomerRegDTO dto=cdao.findByName(uname);
		if(dto!=null) {
			int flagvalue=dto.getFlag();
			//System.out.println("Flag: " + flagvalue);
			if(flagvalue==0) {
				return true;
			}
			else {
				return false;
			}
		}
		return false;
	}
	
	@Override
	public boolean checkUser(String uname, String pwd) {
		CustomerRegDAO cdao=CustomerRegDAOImpl.getServiceImpl();
		CustomerRegDTO dto=cdao.findByName(uname);
		//System.out.println(dto + " ***");
		if(dto!=null) {
			if(dto.getPassword().equals(pwd)) {
				return true;
			}
			else {
				return false;
			}
		}
		return false;
	}
	@Override
	public int updateFlag(int flag, String cust_name) {
		CustomerRegDAO cdao=CustomerRegDAOImpl.getServiceImpl();
		CustomerRegDTO dto=cdao.findByName(cust_name);
		if(dto!=null) {
			dto.setFlag(flag);
			cdao.updateCustomer(dto);
			return 1;
		}
		return 0;		
	}
	
}