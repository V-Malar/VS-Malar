package action;

import java.util.UUID;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.CustomerDAO;
import dao.CustomerDAOImpl;
import dao.CustomerDTO;
import dao.CustomerRegDAO;
import dao.CustomerRegDAOImpl;
import dao.CustomerRegDTO;

public class RegisterAction extends Action {
	public RegisterAction() {
		System.out.println("Register Action impl object created...");
	}

	private static RegisterAction cs;

	synchronized public static RegisterAction getServiceImpl() {
		if (cs == null) {
			cs = new RegisterAction();
			return cs;
		} else {
			return cs.createClone();
		}
	}

	private RegisterAction createClone() {
		try {
			return (RegisterAction) super.clone();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) {
		String uname = request.getParameter("uname");
		String uemail = request.getParameter("uemail");
		String upass = request.getParameter("upass");
		String uaddress = request.getParameter("uaddress");
		String utele = request.getParameter("utele");

		CustomerRegDAO cdao;
		CustomerRegDTO dto;

		CustomerDAO ldao;
		CustomerDTO ldto;
		try {
			cdao = new CustomerRegDAOImpl();
			dto = new CustomerRegDTO();
			dto.setC_id(Math.abs(UUID.randomUUID().hashCode()));
			dto.setEmail(uemail);
			dto.setPassword(upass);
			dto.setAddress(uaddress);
			dto.setTele(utele);
			dto.setUsername(uname);
			dto.setFlag(0);
			cdao.insertCustomer(dto);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "lang.success";
	}

	@Override
	public void init(Logger log) {
		// TODO Auto-generated method stub
		log.info("Working in RegisterAction class");
	}
}
