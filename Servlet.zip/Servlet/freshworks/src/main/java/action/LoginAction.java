package action;

import java.util.LinkedList;
import java.util.List;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.CustomerDAOImpl;
import service.CustomerService;
import service.CustomerServiceImpl;

public class LoginAction extends Action implements Cloneable {

	public LoginAction() {
		System.out.println("Login Action impl object created...");
	}

	private static LoginAction cs;

	synchronized public static LoginAction getServiceImpl() {
		if (cs == null) {
			cs = new LoginAction();
			return cs;
		} else {
			return cs.createClone();
		}
	}

	private LoginAction createClone() {
		try {
			return (LoginAction) super.clone();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) {
		String uname = request.getParameter("uname");
		String upass = request.getParameter("upass");
		CustomerService cs = CustomerServiceImpl.getServiceImpl();
		List<String> list = new LinkedList<String>();
		HttpSession session = request.getSession();
		session.setAttribute("list", list);
		if (cs.checkUser(uname, upass)) {
			System.out.println("Name checked..");
			if (cs.checkFlag(uname)) {
				
				
				session.setAttribute("uname", uname);
				cs.updateFlag(1, uname);
				return "login.success";
			} else {
				return "login.alreadylogedin";
			}
		} else {
			return "login.register";
		}
	}

	@Override
	public void init(Logger log) {
		// TODO Auto-generated method stub
		log.info("Working in LoginAction class");
	}
}
