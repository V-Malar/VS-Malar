package action;

public class Price {
int amount = 0, count = 0;

public Price(int amount, int count) {
	this.amount = amount;
	this.count = count;
}

public int getAmount() {
	return amount;
}

public void setAmount(int amount) {
	this.amount = amount;
}

public int getCount() {
	return count;
}

public void setCount(int count) {
	this.count = count;
}

@Override
public String toString() {
	return "Price [amount=" + amount + ", count=" + count + "]";
}

}
