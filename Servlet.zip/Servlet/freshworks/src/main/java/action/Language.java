package action;

import java.io.IOException;
import java.util.ResourceBundle;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.ServletResponse;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class Language  extends TagSupport{
	private static final long serialVersionUID = 1L;
	private String content;
	public void setContent(String content) {
		this.content=content;
	}
	@Override
	public int doEndTag() throws JspException {
		JspWriter out =pageContext.getOut();
		ServletContext app=pageContext.getServletContext();
		ResourceBundle rb=(ResourceBundle) app.getAttribute("rb");
		try {
			out.println(rb.getString(content));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return super.doEndTag();
	}

}
