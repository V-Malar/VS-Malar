package action;

public class Multiply {
int total = 0, count = 0, totalamount = 0;

public int getTotal() {
	return total;
}

public void setTotal(int total) {
	this.total = total;
}

public int getCount() {
	return count;
}

public void setCount(int count) {
	this.count = count;
}
public int totalamount()
{
	return totalamount + (getTotal() * getCount());
}
}
