package test;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.jupiter.api.Test;

import action.LoginAction;
import control.ActionServlet;
import control.RequestProcessor;

class LoginActionTest {

	@Test
	void testExecute() throws ServletException, IOException {
		ActionServlet action = new ActionServlet();
		
		HttpServlet http = new ActionServlet();
		LoginAction loginAction = LoginAction.getServiceImpl();
		
		HttpServletRequest request = null;
		HttpServletResponse response = null;
		
		request.setAttribute("Renu", loginAction);
		request.setAttribute("renu", loginAction);
		
		loginAction.execute(request, response);
		//System.out.println(result);
	}

	

	@Test
	void testObject() {
		fail("Not yet implemented");
	}

	@Test
	void testGetClass() {
		fail("Not yet implemented");
	}

	@Test
	void testHashCode() {
		fail("Not yet implemented");
	}

	@Test
	void testEquals() {
		fail("Not yet implemented");
	}

	@Test
	void testClone() {
		fail("Not yet implemented");
	}

}
