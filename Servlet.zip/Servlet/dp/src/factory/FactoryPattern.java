package factory;

public class FactoryPattern {

	public static void main(String[] args) {
		ShoeShop seller = new RamuShoeShop();
		
		ShoeFactory factory = new LakhaniShoeFactory();
		
		// dependency injection
		seller.setFactory(factory);
		
		Customer customer = new Customer();
		customer.name = "Shinchan";
		Shoe shoe = seller.sell(customer);
		System.out.println(shoe.toString());

	}

}
abstract class Shoe
{
	
}
class SportsShoe extends Shoe
{

	@Override
	public String toString() {
		return "SportsShoe [getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	
}
class LeatherShoe extends Shoe
{

	@Override
	public String toString() {
		return "LeatherShoe [getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	
}

interface Manufacturer
{
	public Shoe make();
}
interface ShoeManufacturer extends Manufacturer
{
	default public Shoe make()
	{
		return makeShoe();
	}
	public Shoe makeShoe();
}

interface Seller
{
	public Shoe sell(Customer customer);
}
interface ShoeSeller extends Seller
{
	default public Shoe sell(Customer customer)
	{
		return sellShoe(customer);
	}
	public Shoe sellShoe(Customer customer);
}

class Customer
{
	String name;
}

abstract class ShoeFactory implements ShoeManufacturer
{
	
}
class BataShoeFactory extends ShoeFactory
{

	@Override
	public Shoe makeShoe() {
		return new LeatherShoe();
	}
	
}
class LakhaniShoeFactory extends ShoeFactory
{

	@Override
	public Shoe makeShoe() {
		return new SportsShoe();
	}
	
}

abstract class ShoeShop implements ShoeSeller
{
	private ShoeFactory factory;
	public void setFactory(ShoeFactory factory)
	{
		this.factory = factory;
	}
	public ShoeFactory getFactory()
	{
		return factory;
	}
}
class RamuShoeShop extends ShoeShop
{

	@Override
	public Shoe sellShoe(Customer customer) {
		return getFactory().make();
	}
	
}