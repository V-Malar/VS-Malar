package factory.pizzaaf;

public interface Clams {
	public String toString();
}
