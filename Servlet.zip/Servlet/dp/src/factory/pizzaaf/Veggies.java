package factory.pizzaaf;

public interface Veggies {
	public String toString();
}
