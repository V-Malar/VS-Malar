package factory.pizzaaf;

public interface Cheese {
	public String toString();
}
