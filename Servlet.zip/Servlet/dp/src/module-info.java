module dp {
	requires java.desktop;
}