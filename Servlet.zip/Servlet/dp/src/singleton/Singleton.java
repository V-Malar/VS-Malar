package singleton;

public class Singleton {
	private Singleton() {
	}
	public static Singleton getInstance()
	{
		//return new Singleton();
		Singleton singleton = null;
		if (singleton == null)
		{
			singleton = new Singleton();
		}
		return singleton;
	}
	public static void main(String[] args) {
		// Singleton s1 = new Singleton();
		new Singleton2();
	}
}
class Singleton2
{
	// public Singleton s = new Singleton(); // can't create object because it is private constructor
	public Object o = Singleton.getInstance();
	public Singleton2()
	{
		System.out.println(o);
	}
}