package singleton;

public class ChocolateBoiler {
	private boolean empty;
	private boolean boiled;
	
	private static ChocolateBoiler uniqueInstance;
	
	private ChocolateBoiler()
	{
		empty = true;
		boiled = false;
	}
	
	public static ChocolateBoiler getInstance()
	{
		if (uniqueInstance == null)
		{
			System.out.println("New Instance..");
			uniqueInstance = new ChocolateBoiler();
		}
			System.out.println("Old Instance..");
			return uniqueInstance;
	}
	
	public boolean isEmpty()
	{
		return empty;
	}
	
	public boolean boil()
	{
		return boiled;
	}
	
	public void fill()
	{
		if (isEmpty())
		{
			empty=false;
			boiled = false;
		}
	}
	
	public void drain()
	{
		if (!isEmpty()&& !boil())
		{
			boiled = true;
		}
	}
	
	
}
