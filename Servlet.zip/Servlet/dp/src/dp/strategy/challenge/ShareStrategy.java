package dp.strategy.challenge;

@FunctionalInterface
public interface ShareStrategy {
	public void share();
}
