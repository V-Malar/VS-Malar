package dp.strategy;

public interface QuackBehavior {
	public void quack();
}
