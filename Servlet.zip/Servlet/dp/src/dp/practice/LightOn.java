package dp.practice;

public class LightOn implements Command{

	Light light;
	SerialLight serialLight;
	public LightOn(Light light, SerialLight serialLight)
	{
		this.light = light;
		this.serialLight = serialLight;
	}
	@Override
	public void execute() {
		System.out.println("Lights turned on..");
		light.lightOn(new SerialLightOn(serialLight));
	}
	
	public void undo()
	{
		light.lightOff(new SerialLightOff(serialLight));
	}

}
