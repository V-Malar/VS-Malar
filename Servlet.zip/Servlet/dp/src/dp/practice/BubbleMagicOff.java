package dp.practice;

public class BubbleMagicOff implements Command {
	Bubble bubble;

	public BubbleMagicOff(Bubble bubble) {
		this.bubble = bubble;
	}

	@Override
	public void execute() {
		bubble.bubbleShootOff();
	}
	
	public void undo()
	{
		bubble.bubbleShootOn();
	}
}
