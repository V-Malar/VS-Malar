package dp.practice;

public class SerialLightOn implements Command{

	SerialLight serialLight;
	public SerialLightOn(SerialLight serialLight)
	{
		this.serialLight = serialLight;
	}
	@Override
	public void execute() {
		serialLight.serialLightOn();
	}

	public void undo()
	{
		serialLight.serialLightOff();
	}
}
