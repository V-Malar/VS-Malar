package dp.practice;

public class SerialLightOff implements Command {
	SerialLight serialLight;

	public SerialLightOff(SerialLight serialLight) {
		this.serialLight = serialLight;
	}

	@Override
	public void execute() {
		serialLight.serialLightOff();
	}
	public void undo()
	{
		serialLight.serialLightOn();
	}
}
