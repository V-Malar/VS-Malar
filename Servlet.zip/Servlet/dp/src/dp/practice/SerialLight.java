package dp.practice;

public class SerialLight {
	String serialLight;

	public SerialLight(String serialLight) {
		this.serialLight = serialLight;
	}
	
	public void serialLightOn()
	{
		System.out.println(serialLight + "Serial lights ON...");
	}
	public void serialLightOff()
	{
		System.out.println(serialLight + "Serial lights OFF...");
	}
}
