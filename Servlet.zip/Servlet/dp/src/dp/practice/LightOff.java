package dp.practice;

public class LightOff implements Command{
	Light light;
	SerialLight serialLight;

	public LightOff(Light light, SerialLight serialLight) {
		this.light = light;
		this.serialLight = serialLight;
	}

	@Override
	public void execute() {
		System.out.println("Lights turned off..");
		light.lightOff(new SerialLightOff(serialLight));
	}
	
	public void undo()
	{
		light.lightOn(new SerialLightOn(serialLight));
	}
}
