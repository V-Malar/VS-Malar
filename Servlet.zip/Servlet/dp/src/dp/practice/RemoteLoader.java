package dp.practice;

public class RemoteLoader {
public static void main(String[] args) {
	MagicRoom magicRoom = new MagicRoom();
	
	Light light = new Light("Bright");
	SerialLight serialLight = new SerialLight("Color");
	LightOn lon = new LightOn(light, serialLight);
	LightOff lof = new LightOff(light, serialLight);
	
	Bubble bubble = new Bubble("Bubbles...");
	BubbleMagicOn bon = new BubbleMagicOn(bubble);
	BubbleMagicOff boff = new BubbleMagicOff(bubble);
	
	Music music = new Music();
	MusicOn mon = new MusicOn(music);
	MusicOff mof = new MusicOff(music);
	
	magicRoom.setCommand(0, lon, lof);
	magicRoom.setCommand(1, bon, boff);
	magicRoom.setCommand(2, mon, mof);
	
	System.out.println(magicRoom);
	
	magicRoom.OnButton(0);
	magicRoom.OnButton(1);
	magicRoom.undoButton(1); // undo the bubble action
	magicRoom.OnButton(2);
		
	Command[] macrosoff = {lof, boff, mof};
	MacroCommand mc = new MacroCommand(macrosoff);
	
	mc.execute();
	
}
}
