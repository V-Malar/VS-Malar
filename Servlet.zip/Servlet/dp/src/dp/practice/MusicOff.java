package dp.practice;

public class MusicOff implements Command {
	Music music;

	public MusicOff(Music music) {
		this.music = music;
	}

	@Override
	public void execute() {
		music.musicOff();
	}

	public void undo() {
		music.musicOn();
	}
}
