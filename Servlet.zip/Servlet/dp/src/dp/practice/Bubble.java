package dp.practice;

public class Bubble {
	String text;

	public Bubble(String text) {
		this.text = text;
	}
	
	public void bubbleShootOn()
	{
		System.out.println(text + "Bubble spilled into the room...Kids are happy...");
	}
	
	public void bubbleShootOff()
	{
		System.out.println(text + "Bubble spilled after 2 mins...");
	}
}
