package dp.practice;

public class Light {
	String light;

	public Light(String light) {
		this.light = light;
	}
	public void lightOn(SerialLightOn serialLightOn)
	{
		System.out.println(light + "Lights are turned ON...");
		serialLightOn.execute();
	}
	public void lightOff(SerialLightOff serialLightOff)
	{
		System.out.println(light + "Lights are turned OFF...");
		serialLightOff.execute();
	}
}

//@FunctionalInterface
//interface serialLightI
//{
//	public void display();
//}