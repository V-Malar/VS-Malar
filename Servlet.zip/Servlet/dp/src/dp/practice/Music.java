package dp.practice;

public class Music {
	public void musicOn()
	{
		System.out.println("Music Turned ON...");
	}
	
	public void musicOff()
	{
		System.out.println("Music Turned OFF...");
	}
}
