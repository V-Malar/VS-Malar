package dp.practice;

public class BubbleMagicOn implements Command{
Bubble bubble;
public BubbleMagicOn(Bubble bubble)
{
	this.bubble = bubble;
}
	@Override
	public void execute() {
		bubble.bubbleShootOn();
	}
	
	public void undo()
	{
		bubble.bubbleShootOff();
	}

}
