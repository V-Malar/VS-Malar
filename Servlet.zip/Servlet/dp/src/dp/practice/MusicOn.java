package dp.practice;

public class MusicOn implements Command{

	Music music;
	
	public MusicOn(Music music)
	{
		this.music = music;
	}
	@Override
	public void execute() {
		music.musicOn();
	}

	public void undo()
	{
		music.musicOff();
	}
}
