package dp.state;

import java.util.Scanner;

abstract class Stage {
	abstract public void pull(Fan fan);
}

class StageZero extends Stage {
	@Override
	public void pull(Fan fan) {
		System.out.println("StageZero..");
		fan.stage = new StageOne();
	}

}

class StageOne extends Stage {
	@Override
	public void pull(Fan fan) {
		System.out.println("StageOne..");
		fan.stage = new StageTwo();
	}
}

class StageTwo extends Stage {
	@Override
	public void pull(Fan fan) {
		System.out.println("StageTwo..");
		fan.stage = new StageZero();
	}
}

class Fan {
	Stage stage = new StageZero();

	public void pull() {
		stage.pull(this);
	}
}

public class State2 {
	public static void main(String[] args) {
		Fan fan = new Fan();
		try (Scanner sc = new Scanner(System.in)) {
			while (true) {
				fan.pull();
				sc.next();
			}
		}
	}
}