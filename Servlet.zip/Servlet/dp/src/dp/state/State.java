package dp.state;

public class State {
	public void stage0()
	{
		System.out.println("Stage - 0");
		stage1();
	}
	public void stage1()
	{
		System.out.println("Stage - 1");
		stage2();
	}
	public void stage2()
	{
		System.out.println("Stage - 2");
		stage3();
	}
	public void stage3()
	{
		System.out.println("Stage - 3");
		stage4();
	}
	public void stage4()
	{
		System.out.println("Stage - 4");
		stage0();
	}
public static void main(String[] args) {
	State fan = new State();
	fan.stage0();
}
}
