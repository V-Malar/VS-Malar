package dp;

public class Mala {

}
