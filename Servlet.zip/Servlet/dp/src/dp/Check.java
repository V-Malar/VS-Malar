package dp;

import java.util.List;
import java.util.stream.Stream;

enum Color
{
	RED, BLUE, GREEN, YELLOW, ORANGE
}
enum Size
{
	SMALL, MEDIUM, LARGE, XLARGE, XXLARGE;
}
enum Type
{
	NORMAL, CASUAL, CARRIER, TRAVEL, RICH, ELEGANT
}
enum Quality
{
	NORMAL, AVERAGE, PREMIUM
}
interface ColorSpecification<T>
{
	boolean isColorApplicable(T t);
}
interface SizeSpecification<T>
{
	boolean isSizeApplicable(T t);
}
interface SpecificForAll<T>
{
	Stream<T> checkAll(List<T> lt, ColorSpecification<T> lc);
}
class CheckAll implements SpecificForAll<Bag>
{

	@Override
	public Stream<Bag> checkAll(List<Bag> lt, ColorSpecification<Bag> lc) {
		return lt.stream().filter(getlc->lc.isColorApplicable(getlc));
	}
	
}
class SpecificCheck implements ColorSpecification<Bag>, SizeSpecification<Bag>
{
Color color;
public SpecificCheck(Color color) {
	this.color = color;
}
	@Override
	public boolean isColorApplicable(Bag t) {
		return t.color == color;
	}
	@Override
	public boolean isSizeApplicable(Bag t) {
		return t.size == Size.LARGE;
	}
}
interface ColorSizeSpecification<T>
{
	boolean isApplicable(T t);
}
interface CheckAllCS<T>
{
	Stream<T> checkAll(List<T> lcs, ColorSizeSpecification<T> listcs);
}
class CS implements CheckAllCS<Bag>
{

	@Override
	public Stream<Bag> checkAll(List<Bag> lcs, ColorSizeSpecification<Bag> listcs) {
		return lcs.stream().filter(getlist->listcs.isApplicable(getlist));
	}
	
}
class SpecificColorSizeCheck implements ColorSizeSpecification<Bag>
{
	Color color;
	Size size;
	public SpecificColorSizeCheck(Color color, Size size)
	{
		this.color = color;
		this.size = size;
	}
	@Override
	public boolean isApplicable(Bag t) {
		return t.color == color && t.size == size;
	}

	
	
}
class Bag
{
	String name;
	Color color;
	Size size;
	Type type;
	Quality quality;
	
	public Bag(String name, Color color, Size size, Type type, Quality quality)
	{
		this.name = name;
		this.color = color;
		this.size = size;
		this.type = type;
		this.quality = quality;
	}

	@Override
	public String toString() {
		return "Bag [name=" + name + ", color=" + color + ", size=" + size + ", type=" + type + ", quality=" + quality
				+ "]";
	}
	
}
class New<T> implements ColorSizeSpecification<T>
{private ColorSizeSpecification<T> first, second;
	public New(ColorSizeSpecification<T> first, ColorSizeSpecification<T> second)
	{
		this.first = first;
		this.second = second;
	}
	@Override
	public boolean isApplicable(T t) {
		return first.isApplicable(t) && second.isApplicable(t);
	}
	
}
public class Check {
public static void main(String[] args) {
	Bag bag1 = new Bag("A", Color.BLUE, Size.LARGE, Type.CARRIER, Quality.AVERAGE);
	Bag bag2 = new Bag("B", Color.GREEN, Size.MEDIUM, Type.CASUAL, Quality.PREMIUM);
	Bag bag3 = new Bag("C", Color.BLUE, Size.LARGE, Type.CARRIER, Quality.AVERAGE);
	
	List<Bag> baglist = List.of(bag1, bag2, bag3);
	System.out.println(baglist.stream().filter(p->p.color==Color.GREEN).toString());
	
	SpecificCheck sc = new SpecificCheck(Color.GREEN);
	boolean b = sc.isColorApplicable(bag2);
	System.out.println(b);
	b = sc.isSizeApplicable(bag3);
	System.out.println(b);
	
	CheckAll ca = new CheckAll();
	ca.checkAll(baglist, new SpecificCheck(Color.BLUE)).forEach(p->System.out.println(p.name));
	
	CS cs = new CS();
	cs.checkAll(baglist, new SpecificColorSizeCheck(Color.GREEN, Size.MEDIUM)).forEach(p->System.out.println(p.name));

	//cs.checkAll(baglist, new New<Bag>(new ColorSizeSpecification<Bag>(), new ColorSizeSpecification<Bag>())).forEach(p->System.out.println(p.name));
}
}
