package dp.command;

public class Light {
	public void lightOn() {
		System.out.println("Now lights turning up...");
	}

	public void lightOff() {
		System.out.println("Lights are turning off...");
	}
}
