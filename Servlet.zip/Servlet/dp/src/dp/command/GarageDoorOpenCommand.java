package dp.command;

public class GarageDoorOpenCommand implements Command{

	GarageDoorOpenController controller;
	
	public GarageDoorOpenCommand(GarageDoorOpenController controller)
	{
		this.controller= controller;
	}
	@Override
	public void execute() {
		// TODO Auto-generated method stub
		System.out.println(controller.controlUp());
	}

}
