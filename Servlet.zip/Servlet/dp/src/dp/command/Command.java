package dp.command;

public interface Command {
	public void execute();
}
