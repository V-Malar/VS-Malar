package dp.command.examples.diner;

public interface Order {
	public void orderUp(Cook cook);
}
