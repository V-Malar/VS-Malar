package dp.command.examples.diner;

public class Cook {
	public void makeFood() {
		System.out.println("Food is Ready...");
		sentFood();
	}
	
	public void sentFood()
	{
		System.out.println("Ready to Serve...");
	}
}
