package dp.command.examples.diner;

public class Diner {
	public static void main(String[] args) {
		Waitress waitress = new Waitress();
		CustomerLambda customer = new CustomerLambda(waitress);
		//Cook cook = new Cook();
		//Order order = new BurgerAndFriesOrder(cook);
		customer.createOrder();
		customer.hungry();
	}
}
