//package dp.command.examples.diner;
//
//public class BurgerAndFriesOrder implements Order{
//Cook cook;
//public BurgerAndFriesOrder(Cook cook)
//{
//	this.cook = cook;
//}
//	@Override
//	public void orderUp() {
//		cook.makeFood();
//	}
//
//}
