package dp.command.examples.diner;

public class Waitress {
	public void takeOrder(Order order)
	{
		order.orderUp(new Cook());
	}
}
