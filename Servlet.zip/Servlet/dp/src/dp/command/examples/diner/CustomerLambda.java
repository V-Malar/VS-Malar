package dp.command.examples.diner;

public class CustomerLambda {
Waitress waitress;

public CustomerLambda(Waitress waitress)
{
	this.waitress = waitress;
}
public void createOrder()
{
	Order order = (cook) -> {cook.makeFood();};
	waitress.takeOrder(order);
}
public void hungry()
{
	
}
}
