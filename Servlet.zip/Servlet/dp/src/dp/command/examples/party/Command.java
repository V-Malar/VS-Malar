package dp.command.examples.party;

public interface Command {
	public void execute();
	public void undo();
}
