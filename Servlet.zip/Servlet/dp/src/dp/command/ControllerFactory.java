//package dp.command;
//
//public class ControllerFactory {
//GarageDoorOpenController controller;
//public ControllerFactory(GarageDoorOpenController controller)
//{
//	this.controller = controller;
//}
//
//public GarageDoorOpenController selected()
//{
//	return controller
//}
//}
