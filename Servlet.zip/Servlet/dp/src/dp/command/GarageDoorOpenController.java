package dp.command;

public class GarageDoorOpenController {
	GarageDoor garage;
	
	public GarageDoorOpenController(GarageDoor garage)
	{
		this.garage = garage;
	}
	public String controlUp()
	{
		garage.up();
		return "Up Success";
	}
	public String controlDown()
	{
		garage.down();
		return "Down Success";
	}
	public String controlStop()
	{
		garage.up();
		return "Stop Success";
	}
}
