package dp.command;

public class GarageDoorTester {
	public static void main(String[] args) {
		
		SimpleRemoteControl remoteControl = new SimpleRemoteControl();
		Light light = new Light();
		GarageDoor garagedoor = new GarageDoor(light);
		GarageDoorOpenController controller = new GarageDoorOpenController(garagedoor);
		Command command = new GarageDoorOpenCommand(controller);
		
		remoteControl.setCommand(command);
		remoteControl.buttonWasPressed();
		
	}
}
