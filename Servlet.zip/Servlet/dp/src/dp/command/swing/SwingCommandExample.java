package dp.command.swing;

import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class SwingCommandExample {
	JFrame frame;
	JPanel panel;
public static void main(String[] args) {
	SwingCommandExample example = new SwingCommandExample();
	example.go();
}
public void go()
{
	frame = new JFrame();
	panel = new JPanel();
	
	// The GUI is the client
	// The buttons are the invokers
	JButton onButton = new JButton("ON");
	JButton offButton = new JButton("OFF");
	
	// The light is the receiver
	JLabel light = new JLabel("light");
	light.setOpaque(true);
	light.setBackground(Color.DARK_GRAY);
	
	onButton.addActionListener(event ->
		light.setBackground(Color.MAGENTA)
	);
	
	offButton.addActionListener(event ->
		light.setBackground(Color.LIGHT_GRAY)
	);
	
	// Set frame Properties
	frame.setContentPane(panel);
	panel.add(onButton);
	panel.add(offButton);
	panel.add(light);
	
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.setSize(300, 300);
	frame.setVisible(true);
}
}
