package dp.command;

public class GarageDoor {
	Light light;
	public GarageDoor(Light light)
	{
		this.light = light;
	}
	public void up()
	{
		System.out.println("Garage Door Opening...");
		light.lightOn();
	}
	
	public void down()
	{
		System.out.println("Garage Door Closing...");
		light.lightOff();
	}
	
	public void stop()
	{
		System.out.println("Garage door stopped moving...");
	}

}
