package shop;

public class Shop3 extends Shop{

}
