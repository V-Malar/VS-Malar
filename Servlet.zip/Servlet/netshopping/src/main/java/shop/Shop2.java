package shop;

public class Shop2 extends Shop{

}
