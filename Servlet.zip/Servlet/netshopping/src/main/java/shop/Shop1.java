package shop;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import control.ConnectionUtility;
import dao.ShopDAO;
import dao.ShopDTO;

public class Shop1 extends Shop implements ShopDAO<Shop1>{
public static void main(String[] args) {
	List<ShopDTO<Shop1>> dto = new Shop1().findAll();
	System.out.println(dto);
}

@Override
public ShopDTO<Shop1> findByName(String name) {
	PreparedStatement ps;
	try
	{
		Connection con = ConnectionUtility.getConnection();
		ps = con.prepareStatement("select * from shopcart1 where item_name = ?");
		ps.setString(1, name);
		ResultSet rs = ps.executeQuery();
		ShopDTO<Shop1> dto = new ShopDTO<Shop1>();
		if (rs.next())
		{
			dto.setItem_name(rs.getString(2));
			dto.setPrice(rs.getFloat(3));
			dto.setImage(rs.getString(4));
			System.out.println(dto);
		}
		else
		{
			return null;
		}
		ConnectionUtility.closeConnection(null, null);
		return dto;
	}
	catch (Exception e) {
		ConnectionUtility.closeConnection(e, null);
		return null;
	}
}

@Override
public List<ShopDTO<Shop1>> findAll() {
	PreparedStatement ps;
	try
	{
		Connection con = ConnectionUtility.getConnection();
		ps = con.prepareStatement("select * from shopcart1");
		ResultSet rs = ps.executeQuery();
		List<ShopDTO<Shop1>> list = new ArrayList<ShopDTO<Shop1>>();
		while (rs.next())
		{
			ShopDTO<Shop1> dto = new ShopDTO<Shop1>();
			dto.setShopid(rs.getInt(1));
			dto.setItem_name(rs.getString(2));
			dto.setPrice(rs.getFloat(3));
			dto.setImage(rs.getString(4));
			list.add(dto);
		}
		ConnectionUtility.closeConnection(null, null);
		return list;
	}
	catch (Exception e) {
		ConnectionUtility.closeConnection(e, null);
		return null;
	}
}

@Override
public int insertShop(ShopDTO<Shop1> dto) {
	// TODO Auto-generated method stub
	return 0;
}

@Override
public int updateShop(ShopDTO<Shop1> dto) {
	// TODO Auto-generated method stub
	return 0;
}

@Override
public int deleteShop(ShopDTO<Shop1> dto) {
	// TODO Auto-generated method stub
	return 0;
}


}
