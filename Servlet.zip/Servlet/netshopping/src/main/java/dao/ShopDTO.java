package dao;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.sql.Blob;
import java.sql.SQLException;

import javax.imageio.ImageIO;

public class ShopDTO<Shop> {
//	byte[] imageBytes = new byte[128];
	int shopid;
	String item_name;
	float price;
	String image;

	public int getShopid() {
		return shopid;
	}

	public void setShopid(int shopid) {
		this.shopid = shopid;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getImage() {
//		byte[] imageBytes = image.getBytes(1, (int)image.length());
//		ByteArrayInputStream byteImage = new ByteArrayInputStream(imageBytes);
//		BufferedImage returnimage = ImageIO.read(byteImage);
//		return byteImage;
		return image;
	}

	public void setImage(String image) throws SQLException, IOException {
//		InputStream inputStream = url.openStream();
//		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
//		byte[] buffer = new byte[4096];
//		int bytesRead;
//		while ((bytesRead = inputStream.read(buffer))!=-1)
//		{
//			outputStream.write(buffer, 0 , bytesRead);
//		}
//		//		blob.setBytes(1, imageBytes);
//		byte[] imageBytes = outputStream.toByteArray();
//		inputStream.close();
//		outputStream.close();
//		this.image = imageBytes;
		this.image = image;
	}

	@Override
	public String toString() {
		return "ShopDTO [shopid=" + shopid + ", item_name=" + item_name + ", price=" + price + ", image=" + image + "]";
	}

}
