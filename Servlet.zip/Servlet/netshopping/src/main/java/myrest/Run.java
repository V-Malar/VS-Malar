package myrest;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import control.RequestProcessor;
import dao.ShopDTO;
import shop.Shop1;

@Path("shop")
public class Run {
	@GET
	@Path("welcome") // not compulsory
	public void sayWelcome() {
		System.out.println("Welcome to Enterprise world.");
	}

	RequestProcessor rp = new RequestProcessor();

	@Context
	private HttpServletRequest request;

	@Context
	private HttpServletResponse response;

	public Run() {
		rp = new RequestProcessor();
	}

	@POST
	@Path("login")
	public String login(@FormParam("uname") String uname, @FormParam("upass") String upass) {
		request.setAttribute("formid", "login");
		String result = rp.process(request, response);
		return result;
	}

	@POST
	@Path("register")
	public String register(@FormParam("uname") String uname, @FormParam("uemail") String email,
			@FormParam("upass") String upass, @FormParam("uaddress") String uaddress,
			@FormParam("utele") String utele) {
		request.setAttribute("formid", "register");
		String result = rp.process(request, response);
		return result;
	}

	@POST
	@Path("logout")
	public String logout(@FormParam("uname") String uname) {
		request.setAttribute("formid", "logout");
		String result = rp.process(request, response);
		return result;
	}

	@POST
	@Path("shoppage")
	public String firstShop(@QueryParam("showpage") String showpage) {
		request.setAttribute("formid", "shop");
		request.setAttribute("shopid", showpage);
		String result = rp.process(request, response);
		return result;
	}
	
	@POST
	@Path("language")
	public String language(@QueryParam("lang") String lang)
	{
		request.setAttribute("formid", "lang");
		request.setAttribute("language", lang);
		String result = rp.process(request, response);
		return result;
	}
	
	@POST
	@Path("lang")
	public String lang(@FormParam("lang") String language)
	{
		request.setAttribute("formid", "lang");
		String result = rp.process(request, response);
		return result;
	}
	
	@GET
	@Path("shop1")
	@Produces(MediaType.APPLICATION_JSON)
	public List<ShopDTO<Shop1>> shop1()
	{
		List<ShopDTO<Shop1>> dto = new Shop1().findAll();
		return dto;
	}
	
	
}
