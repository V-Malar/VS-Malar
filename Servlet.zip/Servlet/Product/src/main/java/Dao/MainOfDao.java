package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import Dto.Product;


public class MainOfDao {
	public static void main(String[] args) throws SQLException {
		
		String url = "jdbc:mysql://localhost:3306/vastpro";
		String driver = "com.mysql.cj.jdbc.Driver";
		String username = "root";
		String password = "Gs#ry!@99";

		Connection con = DriverManager.getConnection(url, username, password);
		
//		Statement createStatement = con.createStatement();
//		int r= createStatement.executeUpdate("insert into product values(1,null,null)");
////		executeQuery.next();
//		System.out.println(r);
		Product product = new  Product();
		product.setPid(1);
		product.setPrice(10);
		product.setImage("https://media.istockphoto.com/id/636739634/photo/banana.jpg?s=612x612&w=0&k=20&c=pO0985tQi1LpWRlWqpRvbab8S5yxgnEOVcs5CHIlcDE=");
		
		ProductDao p = new ProductDaos(con);
		int r =p.insertProduct(product);
		System.out.println(r);
		
		
	}

}
