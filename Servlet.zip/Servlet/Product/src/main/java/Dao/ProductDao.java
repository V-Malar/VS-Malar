package Dao;

import java.util.List;

import Dto.Product;

public interface ProductDao {
	
	public int insertProduct(Product product);
	public Product retriveProduct(int pid);
	public List<Product> findAllProduct();
	public int update(Product product);
	public int deleteProduct(int pid);
	

}
