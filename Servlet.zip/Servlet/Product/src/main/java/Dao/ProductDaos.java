package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import Dto.Product;

public class ProductDaos implements ProductDao {
	Connection con ;
	
	public ProductDaos(Connection con ) throws SQLException {
		this.con=con;
		
	}
	

	@Override
	public int insertProduct(Product product) {
		int result=0;
		String sql = " insert into product values (?,?,?)";
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, product.getPid());
			ps.setFloat(2, product.getPrice());
			ps.setString(3, product.getImage());
			result=ps.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
		
	}

	@Override
	public Product retriveProduct(int pid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> findAllProduct() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int update(Product product) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteProduct(int pid) {
		// TODO Auto-generated method stub
		return 0;
	}

}
